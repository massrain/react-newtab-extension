<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWebsitesDefaultTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('websites_default', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('extension_id');
            $table->foreign('extension_id')->references('id')->on('extensions')->onDelete('cascade');
            $table->string('name', 255);
            $table->string('link', 255);
            $table->string('icon', 255);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('websites_default');
    }
}
