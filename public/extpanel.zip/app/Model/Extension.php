<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Extension extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [];

    public function WebsitesExtra()
    {
        return $this->hasOne('App\Model\WebsitesExtra');
    }
    public function WebsitesDefault()
    {
        return $this->hasOne('App\Model\WebsitesDefault');
    }
}
