<?php

namespace App\Http\Controllers\Extension;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Model\Extension;

class ExtensionController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        try {
            $action = Extension::with(['WebsitesDefault', 'WebsitesExtra'])->get();
            return response()->json($action, 200);
        } catch (\Throwable $th) {
            throw $th;
            return response()->json([
                'success' => false,
                'error' => 'An error while resolving request.'
            ], 400);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|string|max:100',
        ]);
        try {
            $action = new Extension;
            $action->name = $request->name;
            $action->save();

            return response()->json([
                'success' => true,
                'messsage' => 'Added succesfully',
                'created' => $action
            ], 201);
        } catch (\Throwable $th) {
            return response()->json([
                'success' => false,
                'error' => 'An error while resolving request.'
            ], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        try {
            $action = Extension::findOrFail($id);
            return response()->json($action, 200);
        } catch (\Throwable $th) {
            //throw $th;
            return response()->json([
                'success' => false,
                'error' => 'An error while resolving request.'
            ], 400);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'name' => 'required|string|max:100',
        ]);
        try {
            $action = Extension::find($id);

            $action->name = $request->name;
            $action->save();

            return response()->json([
                'success' => true,
                'messsage' => 'Added succesfully',
                'updated' => $action
            ], 202);
        } catch (\Throwable $th) {
            return response()->json([
                'success' => false,
                'error' => 'An error while resolving request.'
            ], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $action = Extension::find($id);
            $action->delete();
            return response()->json([
                'success' => true,
                'messsage' => 'Deleted succesfully',
                'created' => $action
            ], 202);
        } catch (\Throwable $th) {
            //throw $th;
            return response()->json([
                'success' => false,
                'error' => 'An error while resolving request.'
            ], 400);
        }
    }
}
