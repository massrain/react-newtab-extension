<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['login', 'register']]);
    }

    /**
     * Get a JWT via given credentials.
     */
    public function login(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|max:50|exists:users|min:4|alpha_dash',
            'secret' => 'required|min:6|string|max:20'
        ]);

        $user = User::where('name', $request->name)->first();
        $passControl = Hash::check($request->secret, $user->password);

        if (!$user) {
            return response()->json(['error' => 'Username does not exist.'], 400);
        } else if (!$passControl) {
            return response()->json([
                'success' => false,
                'result' => 'Password does not match',
            ], 400);
        } else {
            $accessToken = $user->createToken('authToken')->accessToken;
            return response()->json([
                'success' => true,
                'result' => 'success',
                'user' => $request->name,
                'access_token' => $accessToken
            ], 200);
        }
    }

    /**
     * Register an user.
     */
    public function register(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|max:50|unique:users,name|min:4|alpha_dash',
            'email' => 'required|max:200|min:6|unique:users|email',
            'secret' => 'required|min:6|string|max:20'
        ]);
        try {
            $user = new User;
            $user->name = $request->name;
            $user->email = $request->email;
            $user->password = Hash::make($request->secret);
            $user->save();

            $accessToken = $user->createToken('authToken')->accessToken;

            return response()->json([
                'success' => true,
                'result' => 'success',
                'new_username' => $user->name,
                'new_userid' => $user->id,
                'access_token' => $accessToken
            ], 201);
        } catch (\Throwable $th) {
            throw $th;
            return response()->json([
                'error' => 'An error while resolving request.'
            ], 400);
        }
    }

    /**
     * Get the authenticated User.
     */
    public function me()
    {
        return Auth::user();
    }
}
