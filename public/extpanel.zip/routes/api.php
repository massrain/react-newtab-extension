<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group(['prefix' => 'auth'], function () {
    Route::post('/login', 'Api\AuthController@login')->name('auth-login');
    Route::post('/logout', 'Api\AuthController@logout');
    Route::post('/refresh', 'Api\AuthController@refresh');
    Route::get('/me', 'Api\AuthController@me');
    Route::post('/register', 'Api\AuthController@register');
});

// EXTENSION ROUTES
Route::group(['prefix' => 'v1'], function () {
    Route::get('/extensions', 'Extension\ExtensionController@index')->name('extension-index');
    Route::post('/extensions', 'Extension\ExtensionController@store')->name('extension-store');
    Route::get('/extensions/{item}', 'Extension\ExtensionController@show')->name('extension-show');
    Route::put('/extensions/{item}', 'Extension\ExtensionController@update')->name('extension-update');
    Route::delete('/extensions/{item}', 'Extension\ExtensionController@destroy')->name('extension-destroy');
});


// WEBSITES_DEFAULT ROUTES
Route::group(['prefix' => 'v1'], function () {
    Route::get('/websites/default', 'Extension\WebsitesDefaultController@index')->name('websitesdefault-index');
    Route::post('/websites/default', 'Extension\WebsitesDefaultController@store')->name('websitesdefault-store');
    Route::get('/websites/default/{item}', 'Extension\WebsitesDefaultController@show')->name('websitesdefault-show');
    Route::put('/websites/default/{item}', 'Extension\WebsitesDefaultController@update')->name('websitesdefault-update');
    Route::delete('/websites/default/{item}', 'Extension\WebsitesDefaultController@destroy')->name('websitesdefault-destroy');
});

// WEBSITES_EXTRA ROUTES
Route::group(['prefix' => 'v1'], function () {
    Route::get('/websites/extra', 'Extension\WebsitesExtraController@index')->name('websitesextra-index');
    Route::post('/websites/extra', 'Extension\WebsitesExtraController@store')->name('websitesextra-store');
    Route::get('/websites/extra/{item}', 'Extension\WebsitesExtraController@show')->name('websitesextra-show');
    Route::put('/websites/extra/{item}', 'Extension\WebsitesExtraController@update')->name('websitesextra-update');
    Route::delete('/websites/extra/{item}', 'Extension\WebsitesExtraController@destroy')->name('websitesextra-destroy');
});
