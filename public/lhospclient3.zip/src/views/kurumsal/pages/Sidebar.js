import React from "react";
import { useHistory } from "react-router-dom";
import { KURUMSAL_HASTAHANEMIZ, KURUMSAL_KALITEPOLITIKASI, KURUMSAL_MISYON, KURUMSAL_VIZYON, KURUMSAL_GALERI } from "../../../helpers/routes";
const Sidebar = () => {
  let history = useHistory();
  return (
    <>
      <div className="col-12 service_col no-margin-bottom">
        <div className="service text-center">
          <div className="service" onClick={() => history.push(KURUMSAL_HASTAHANEMIZ)}>
            <div className="service_title p-1">Hastahanemiz</div>
          </div>
        </div>
      </div>
      <div className="col-12 service_col no-margin-bottom">
        <div className="service text-center">
          <div className="service" onClick={() => history.push(KURUMSAL_KALITEPOLITIKASI)}>
            <div className="service_title p-1">Kalite Politikamız</div>
          </div>
        </div>
      </div>
      <div className="col-12 service_col no-margin-bottom">
        <div className="service text-center">
          <div className="service" onClick={() => history.push(KURUMSAL_MISYON)}>
            <div className="service_title p-1">Misyonumuz</div>
          </div>
        </div>
      </div>
      <div className="col-12 service_col no-margin-bottom">
        <div className="service text-center">
          <div className="service" onClick={() => history.push(KURUMSAL_VIZYON)}>
            <div className="service_title p-1">Vizyonumuz</div>
          </div>
        </div>
      </div>
      <div className="col-12 service_col no-margin-bottom">
        <div className="service text-center">
          <div className="service" onClick={() => history.push(KURUMSAL_GALERI)}>
            <div className="service_title p-1">Galeri</div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
