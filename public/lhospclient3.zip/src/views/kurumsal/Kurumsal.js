import React from "react";
import { Switch, Route } from "react-router-dom";
import { KURUMSAL_HASTAHANEMIZ, KURUMSAL_KALITEPOLITIKASI, KURUMSAL_MISYON, KURUMSAL_VIZYON, KURUMSAL_GALERI } from "../../helpers/routes";
import Hastahanemiz from "./pages/Hastahanemiz";
import KalitePolitikasi from "./pages/KalitePolitikasi";
import Galeri from "./pages/Galeri";
import Misyon from "./pages/Misyon";
import Vizyon from "./pages/Vizyon";

const Kurumsal = () => {
  return (
    <>
      <Switch>
        <Route exact path={KURUMSAL_HASTAHANEMIZ}>
          <Hastahanemiz />
        </Route>
        <Route exact path={KURUMSAL_KALITEPOLITIKASI}>
          <KalitePolitikasi />
        </Route>
        <Route exact path={KURUMSAL_MISYON}>
          <Misyon />
        </Route>
        <Route exact path={KURUMSAL_VIZYON}>
          <Vizyon />
        </Route>
        <Route exact path={KURUMSAL_GALERI}>
          <Galeri />
        </Route>
      </Switch>
    </>
  );
};

export default Kurumsal;
