import React from "react";
import { Switch, Route } from "react-router-dom";
import {
  KURUMSAL_HASTAHANEMIZ,
  KURUMSAL_KALITEPOLITIKASI,
  KURUMSAL_MISYON,
  KURUMSAL_VIZYON,
  KURUMSAL_GALERI,
  KURUMSAL_HASTAHAKLARI,
  KURUMSAL_HASTASORUMLULUKLARI,
  KURUMSAL_ZIYARETCIREHBERI,
  KURUMSAL_REFAKATCIREHBERI,
  KURUMSAL_HALKLAILISKILER,
  KURUMSAL_ANLASMALIKURUMLAR
} from "../../helpers/routes";
import Hastahanemiz from "./pages/Hastahanemiz";
import KalitePolitikasi from "./pages/KalitePolitikasi";
import Galeri from "./pages/Galeri";
import Misyon from "./pages/Misyon";
import Vizyon from "./pages/Vizyon";
import HastaHaklari from "./hasta/HastaHaklari";
import HastaSorumluluklari from "./hasta/HastaSorumluluklari";
import ZiyaretciRehberi from "./hasta/ZiyaretciRehberi";
import RefakatciRehberi from "./hasta/RefakatciRehberi";
import HalklaIliskiler from "./hasta/HalklaIliskiler";
import AnlasmaliKurumlar from "./hasta/AnlasmalıKurumlar";

const Kurumsal = () => {
  return (
    <>
      <Switch>
        <Route exact path={KURUMSAL_HASTAHANEMIZ}>
          <Hastahanemiz />
        </Route>
        <Route exact path={KURUMSAL_KALITEPOLITIKASI}>
          <KalitePolitikasi />
        </Route>
        <Route exact path={KURUMSAL_MISYON}>
          <Misyon />
        </Route>
        <Route exact path={KURUMSAL_VIZYON}>
          <Vizyon />
        </Route>
        <Route exact path={KURUMSAL_GALERI}>
          <Galeri />
        </Route>
        <Route exact path={KURUMSAL_HASTAHAKLARI}>
          <HastaHaklari />
        </Route>
        <Route exact path={KURUMSAL_HASTASORUMLULUKLARI}>
          <HastaSorumluluklari />
        </Route>
        <Route exact path={KURUMSAL_ZIYARETCIREHBERI}>
          <ZiyaretciRehberi />
        </Route>
        <Route exact path={KURUMSAL_REFAKATCIREHBERI}>
          <RefakatciRehberi />
        </Route>
        <Route exact path={KURUMSAL_HALKLAILISKILER}>
          <HalklaIliskiler />
        </Route>
        <Route exact path={KURUMSAL_ANLASMALIKURUMLAR}>
          <AnlasmaliKurumlar />
        </Route>
      </Switch>
    </>
  );
};

export default Kurumsal;
