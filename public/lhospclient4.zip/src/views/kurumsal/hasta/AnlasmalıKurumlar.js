import React from "react";
import Sidebar from "../pages/Sidebar";

const AnlasmalıKurumlar = () => {
  return (
    <>
      <div className="services mt-5">
        <div className="container">
          <div className="row">
            <div className="col-9">
              <div className="row">
                <div className="col text-center">
                  <div className="section_title_container text-left">
                    <div className="section_title">
                      <h2>Anlaşmalı Kurumlar</h2>
                    </div>
                    <div className="row no-gutters my-3">
                      <div className="col-4">
                        <img src="/assets/images/new/kurumlar/sgklogo.gif" alt="Sosyal Güvenlik Kurumu" />
                      </div>
                      <div className="col-4">
                        <img src="/assets/images/new/kurumlar/tbmm.jpg" alt="Türkiye Büyük Millet Meclisi" />
                      </div>
                      <div className="col-4">
                        <img src="/assets/images/new/kurumlar/acibadem.jpg" alt="Acıbadem Sigorta" />
                      </div>
                      <div className="col-4">
                        <img src="/assets/images/new/kurumlar/allianz.jpg" alt="Allianz Sigorta" />
                      </div>
                      <div className="col-4">
                        <img src="/assets/images/new/kurumlar/interpartner.jpg" alt="Interpartner Assistance" />
                      </div>
                      <div className="col-4">
                        <img src="/assets/images/new/kurumlar/paphregenelyasam.png" alt="Maphre Genel Yaşam" />
                      </div>
                      <div className="col-4">
                        <img src="/assets/images/new/kurumlar/yapikredi.jpg" alt="Yapı Kredi Sigorta" />
                      </div>
                      <div className="col-4">
                        <img src="/assets/images/new/kurumlar/basakgroupama.jpg" alt="Başak Groupama" />
                      </div>
                      <div className="col-4">
                        <img src="/assets/images/new/kurumlar/sekerbank.jpg" alt="Şekerbank" />
                      </div>
                      <div className="col-4">
                        <img src="/assets/images/new/kurumlar/aksigorta.jpg" alt="Ak Sigorta" />
                      </div>
                      <div className="col-4">
                        <img src="/assets/images/new/kurumlar/ergo.jpg" alt="Ergo Sigorta" />
                      </div>
                      <div className="col-4">
                        <img src="/assets/images/new/kurumlar/zurich.jpg" alt="Zurich Sigorta" />
                      </div>
                      <div className="col-4">
                        <img src="/assets/images/new/kurumlar/axa.jpg" alt="Axa Hayat Emeklilik" />
                      </div>
                      <div className="col-4">
                        <img src="/assets/images/new/kurumlar/demir.jpg" alt="Demir Hayat" />
                      </div>
                      <div className="col-4">
                        <img src="/assets/images/new/kurumlar/turkiyeassist.jpg" alt="Türkiye Assist" />
                      </div>
                      <div className="col-4">
                        <img src="/assets/images/new/kurumlar/Anadolu-sigorta.jpg" alt="Anadolu Sigorta" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-3">
              <div className="row services_row">
                <Sidebar />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AnlasmalıKurumlar;
