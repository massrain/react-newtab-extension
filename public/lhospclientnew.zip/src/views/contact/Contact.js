import React, { useEffect } from "react";
import "../../styles/contact.css";
import "../../styles/contact_responsive.css";

import overlay from "../../imports/home_overlay.png";

const Contact = () => {
  useEffect(() => {
    const script = document.createElement("script");
    script.src = "/assets/js/contact.js";
    script.async = true;
    document.body.appendChild(script);

    const script2 = document.createElement("script");
    script2.src = "/assets/plugins/parallax-js-master/parallax.min.js";
    script2.async = true;
    document.body.appendChild(script2);

    return () => {
      document.body.removeChild(script);
      document.body.removeChild(script2);
    };
  }, []);
  return (
    <>
      {/* Home */}
      <div className="home d-flex flex-column align-items-start justify-content-end">
        <div
          className="parallax_background parallax-window"
          data-parallax="scroll"
          data-image-src="/assets/images/contact.jpg"
          data-speed="0.8"
        />
        <div className="home_overlay">
          <img src={overlay} alt="" />
        </div>
        <div className="home_container">
          <div className="container">
            <div className="row">
              <div className="col">
                <div className="home_content">
                  <div className="home_title">İletişim</div>
                  <div className="home_text">7/24 saat bize ulaşabileceğiniz yollar..</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Contact */}
      <div className="contact">
        <div className="container">
          <div className="row">
            {/* Contact Form */}
            <div className="col-lg-6">
              <div className="contact_form_container">
                <div className="contact_form_title">Randevu Formu</div>
                <form action="#" className="contact_form" id="contact_form">
                  <div className="d-flex flex-row align-items-start justify-content-between flex-wrap">
                    <input type="text" className="contact_input" placeholder="İsminiz" required="required" />
                    <input type="email" className="contact_input" placeholder="Mail adresi" required="required" />
                    <input type="tel" className="contact_input" placeholder="Telefon numaranız" required="required" />
                    <select className="contact_select contact_input" required>
                      <option disabled selected>
                        Bölüm
                      </option>
                      <option>Bölüm 1</option>
                      <option>Bölüm 2</option>
                      <option>Bölüm 3</option>
                      <option>Bölüm 4</option>
                      <option>Bölüm 5</option>
                    </select>
                    <select className="contact_select contact_input" required="required">
                      <option disabled selected>
                        Doktor
                      </option>
                      <option>Doktor 1</option>
                      <option>Doktor 2</option>
                      <option>Doktor 3</option>
                      <option>Doktor 4</option>
                      <option>Doktor 5</option>
                    </select>
                    <input
                      type="text"
                      id="datepicker"
                      className="contact_input datepicker"
                      placeholder="Date"
                      required="required"
                    />
                  </div>
                  <button className="button button_1 contact_button trans_200">make an appointment</button>
                </form>
              </div>
            </div>
            {/* Contact Content */}
            <div className="col-lg-5 offset-lg-1 contact_col">
              <div className="contact_content">
                <div className="contact_content_title">İletişime geçin</div>
                <div className="contact_content_text">
                  <p>
                    Odio ultrices ut. Etiam ac erat ut enim maximus accumsan vel ac nisl. Duis feug iat bibendum orci,
                    non elementum urna. Cras sit amet sapien aliquam.
                  </p>
                </div>
                <div className="direct_line d-flex flex-row align-items-center justify-content-start">
                  <div className="direct_line_title text-center">Telefon</div>
                  <div className="direct_line_num text-center">444 6 112</div>
                </div>
                <div className="contact_info">
                  <ul>
                    <li className="d-flex flex-row align-items-start justify-content-start">
                      <div>Adres</div>
                      <div>Pazaryeri Mahallesi Şehit Hasan Küçükçoban Cad. No: 22 48300 Fethiye/ MUĞLA</div>
                    </li>
                    <li className="d-flex flex-row align-items-start justify-content-start">
                      <div>Faks</div>
                      <div>+90 252 646 5157</div>
                    </li>
                    <li className="d-flex flex-row align-items-start justify-content-start">
                      <div>E-mail</div>
                      <div>info@letoonhospital.com.tr</div>
                    </li>
                  </ul>
                </div>
                <div className="contact_social">
                  <ul className="d-flex flex-row align-items-center justify-content-start">
                    <li>
                      <a href="#">
                        <i className="fa fa-pinterest" />
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i className="fa fa-facebook" />
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i className="fa fa-twitter" />
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i className="fa fa-dribbble" />
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i className="fa fa-behance" />
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i className="fa fa-linkedin" />
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="row google_map_row">
            <div className="col">
              {/* Contact Map */}
              <div className="contact_map">
                {/* Google Map */}
                <div className="map">
                  <div id="google_map" className="google_map">
                    <div className="map_container">
                      <div id="map" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Contact;
