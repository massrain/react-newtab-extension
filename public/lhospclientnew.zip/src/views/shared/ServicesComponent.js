import React from "react";
import { useHistory } from "react-router-dom";
import {
  SERVICES_ICHASTALIKLARI,
  SERVICES_BEYINVESINIRCERRAHISI,
  SERVICES_UROLOJI,
  SERVICES_ORTOPEDIVETRAVMATOLOJI,
  SERVICES_GOZHASTALIKLARI,
  SERVICES_COCUKHASTALIKLARI,
  SERVICES_KULAKBURUNBOGAZ,
  SERVICES_DIS,
  SERVICES_GENELCERRAHI,
  SERVICES_ANASTEZIVEREANIMASYON,
  SERVICES_KADINDOGUM,
  SERVICES_ACILSERVIS,
  SERVICES_YABANCIHASTALIKLAR,
  SERVICES_RADYOLOJI,
  SERVICES_BIYOKIMYA,
  SERVICES_COCUKCERRAHISI,
  SERVICES_FTR,
  SERVICES_KARDIYOLOJI,
  SERVICES_BESLENMEVEDIYET,
  SERVICES_GOGUSHASTALIKLARI
} from "../../helpers/routes";

const ServicesComponent = () => {
  return (
    <>
      {/* Services */}
      <div className="services">
        <div className="container">
          <div className="row">
            <div className="col text-center">
              <div className="section_title_container">
                <div className="section_subtitle">Letoon Hastahanesi</div>
                <div className="section_title">
                  <h2>Birimlerimiz</h2>
                </div>
              </div>
            </div>
          </div>
          <div className="row services_row">
            {/* Service */}
            <SingleService icon={"/assets/images/icon_1.svg"} url={SERVICES_ICHASTALIKLARI} title={"İç hastalıkları"} />
            <SingleService icon={"/assets/images/icon_2.svg"} url={SERVICES_BEYINVESINIRCERRAHISI} title={"Beyin ve Sinir Cerrahisi"} />
            <SingleService icon={"/assets/images/icon_3.svg"} url={SERVICES_UROLOJI} title={"Üroloji"} />
            <SingleService icon={"/assets/images/icon_4.svg"} url={SERVICES_ORTOPEDIVETRAVMATOLOJI} title={"Ortopedi ve Travmatoloji"} />
            <SingleService icon={"/assets/images/icon_5.svg"} url={SERVICES_GOZHASTALIKLARI} title={"Göz Hastalıkları"} />
            <SingleService icon={"/assets/images/icon_6.svg"} url={SERVICES_COCUKHASTALIKLARI} title={"Çocuk Hastalıkları"} />
            <SingleService icon={"/assets/images/icon_7.svg"} url={SERVICES_KULAKBURUNBOGAZ} title={"Kulak Burun Boğaz"} />
            <SingleService icon={"/assets/images/icon_8.svg"} url={SERVICES_DIS} title={"Diş"} />
            <SingleService icon={"/assets/images/icon_1.svg"} url={SERVICES_GENELCERRAHI} title={"Genel Cerrahi"} />
            <SingleService icon={"/assets/images/icon_2.svg"} url={SERVICES_ANASTEZIVEREANIMASYON} title={"Anastezi ve Reanimasyon"} />
            <SingleService icon={"/assets/images/icon_3.svg"} url={SERVICES_KADINDOGUM} title={"Kadın Doğum"} />
            <SingleService icon={"/assets/images/icon_4.svg"} url={SERVICES_ACILSERVIS} title={"Acil Servis"} />
            <SingleService icon={"/assets/images/icon_5.svg"} url={SERVICES_YABANCIHASTALIKLAR} title={"Yabancı Hastalıklar"} />
            <SingleService icon={"/assets/images/icon_6.svg"} url={SERVICES_RADYOLOJI} title={"Radyoloji"} />
            <SingleService icon={"/assets/images/icon_7.svg"} url={SERVICES_BIYOKIMYA} title={"Biyokimya"} />
            <SingleService icon={"/assets/images/icon_8.svg"} url={SERVICES_COCUKCERRAHISI} title={"Çocuk Cerrahisi"} />
            <SingleService icon={"/assets/images/icon_1.svg"} url={SERVICES_FTR} title={"F. T. R"} />
            <SingleService icon={"/assets/images/icon_2.svg"} url={SERVICES_KARDIYOLOJI} title={"Kardiyoloji"} />
            <SingleService icon={"/assets/images/icon_3.svg"} url={SERVICES_BESLENMEVEDIYET} title={"Beslenme ve Diyet"} />
            <SingleService icon={"/assets/images/icon_4.svg"} url={SERVICES_GOGUSHASTALIKLARI} title={"Göğüs Hastalıkları"} />
          </div>
        </div>
      </div>
    </>
  );
};

export default ServicesComponent;

const SingleService = props => {
  let history = useHistory();
  return (
    <div className="col-xl-4 col-md-6 service_col">
      <div className="service text-center">
        <div className="service" onClick={() => history.push(props.url)}>
          <div className="icon_container d-flex flex-column align-items-center justify-content-center ml-auto mr-auto">
            <div className="icon">
              <img src={props.icon} alt="" />
            </div>
          </div>
          <div className="service_title">{props.title}</div>
        </div>
      </div>
    </div>
  );
};
