import React, { useEffect } from "react";
import ServicesComponent from "../shared/ServicesComponent";
import Newsletter from "../shared/Newsletter";
import { CONTACT } from "../../helpers/routes";
import { Link } from "react-router-dom";

import "../../styles/main_styles.css";
import "../../styles/responsive.css";

const Home = () => {
  useEffect(() => {
    const script = document.createElement("script");
    script.src = "/assets/js/custom.js";
    script.async = true;
    document.body.appendChild(script);
    return () => {
      document.body.removeChild(script);
    };
  }, []);
  return (
    <>
      {/* Home */}
      <div className="home">
        {/* Home Slider */}
        <div className="home_slider_container">
          <div className="owl-carousel owl-theme home_slider">
            {/* Slide */}
            <div className="owl-item">
              <div className="background_image" style={{ backgroundImage: "url('/assets/images/new/bg_1.webp')" }} />
              <div className="home_container">
                <div className="container">
                  <div className="row">
                    <div className="col">
                      <div className="home_content">
                        <div className="home_subtitle">#1 Fethiye'nin ilk özel hastahenesi</div>
                        <div className="home_title">Sağlığınız bizim için önemlidir.</div>
                        <div className="home_text">
                          <p>
                            7/24 Acil Servis - Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec malesuada
                            lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse
                            cursus faucibus finibus.
                          </p>
                        </div>
                        <div className="home_buttons d-flex flex-row align-items-center justify-content-start">
                          <div className="button button_1 trans_200">
                            <a href="blog.html">Duyurular</a>
                          </div>
                          <div className="button button_2 trans_200">
                            <a href="http://212.156.247.126/randevu/randevu.aspx">Randevu Al</a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* Slide */}
            <div className="owl-item">
              <div className="background_image" style={{ backgroundImage: "url(/assets/images/new/bg_3.webp)" }} />
              <div className="home_container">
                <div className="container">
                  <div className="row">
                    <div className="col">
                      <div className="home_content">
                        <div className="home_subtitle">#1 Fethiye'nin ilk özel hastahenesi</div>
                        <div className="home_title">Sağlığınız bizim için önemlidir.</div>
                        <div className="home_text">
                          <p>
                            7/24 Acil Servis - Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec malesuada
                            lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse
                            cursus faucibus finibus.
                          </p>
                        </div>
                        <div className="home_buttons d-flex flex-row align-items-center justify-content-start">
                          <div className="button button_1 trans_200">
                            <a href="blog.html">Duyurular</a>
                          </div>
                          <div className="button button_2 trans_200">
                            <a href="http://212.156.247.126/randevu/randevu.aspx">Randevu Al</a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* Slide */}
            <div className="owl-item">
              <div className="background_image" style={{ backgroundImage: "url(assets/images/home_slider.jpg)" }} />
              <div className="home_container">
                <div className="container">
                  <div className="row">
                    <div className="col">
                      <div className="home_content">
                        <div className="home_subtitle">#1 Fethiye'nin ilk özel hastahenesi</div>
                        <div className="home_title">Sağlığınız bizim için önemlidir.</div>
                        <div className="home_text">
                          <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec malesuada lorem maximus
                            mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus
                            finibus.
                          </p>
                        </div>
                        <div className="home_buttons d-flex flex-row align-items-center justify-content-start">
                          <div className="button button_1 trans_200">
                            {/* //TODO: Blog linkleri */}
                            <a href="blog.html">Duyurular</a>
                          </div>
                          <div className="button button_2 trans_200">
                            <a href="http://212.156.247.126/randevu/randevu.aspx">Randevu Al</a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* Home Slider Dots */}
          <div className="home_slider_dots">
            <ul
              id="home_slider_custom_dots"
              className="home_slider_custom_dots d-flex flex-row align-items-center justify-content-start"
            >
              <li className="home_slider_custom_dot trans_200 active" />
              <li className="home_slider_custom_dot trans_200" />
              <li className="home_slider_custom_dot trans_200" />
            </ul>
          </div>
        </div>
      </div>
      {/* Intro */}
      <div className="intro">
        <div className="container">
          <div className="row">
            {/* Intro Content */}
            <div className="col-lg-6 intro_col">
              <div className="intro_content">
                <div className="section_title_container">
                  <div className="section_subtitle">Özel Letoon Hastahanesi</div>
                  <div className="section_title">
                    <h2>Hastahanemize hoş geldiniz.</h2>
                  </div>
                </div>
                <div className="intro_text">
                  <p>
                    Integer aliquet congue libero, eu gravida odio ultrices ut. Etiam ac erat ut enim maximus accumsan
                    vel ac nisl. Duis feugiat bibendum orci, non elementum urna vestibulum in. Nulla facilisi. Nulla
                    egestas vel lacus sed interdum. Sed mollis, orci elementum eleifend tempor, nunc libero porttitor
                    tellus, vel pharetra metus dolor.
                  </p>
                </div>
                <div className="milestones">
                  <div className="row milestones_row">
                    {/* Milestone */}
                    <div className="col-md-4 milestone_col">
                      <div className="milestone">
                        <div className="milestone_counter" data-end-value={5000} data-sign-before="+">
                          0
                        </div>
                        <div className="milestone_text">Hasta</div>
                      </div>
                    </div>
                    {/* Milestone */}
                    <div className="col-md-4 milestone_col">
                      <div className="milestone">
                        <div className="milestone_counter" data-end-value={13}>
                          0
                        </div>
                        <div className="milestone_text">Birim</div>
                      </div>
                    </div>
                    {/* Milestone */}
                    <div className="col-md-4 milestone_col">
                      <div className="milestone">
                        <div className="milestone_counter" data-end-value={35}>
                          0
                        </div>
                        <div className="milestone_text">Hekim</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* Intro Form */}
            <div className="col-lg-6 intro_col">
              <div className="intro_form_container">
                <div className="intro_form_title">Randevu Formu</div>
                <form action="http://212.156.247.126/randevu/randevu.aspx" className="intro_form" id="intro_form">
                  <div className="d-flex flex-row align-items-start justify-content-between flex-wrap">
                    <input type="text" className="intro_input" placeholder="İsminiz" required="required" />
                    <input type="email" className="intro_input" placeholder="Mail adresi" required="required" />
                    <input type="tel" className="intro_input" placeholder="Telefon numaranız" required="required" />
                    <select className="intro_select intro_input" required defaultValue="">
                      <option disabled value="">
                        Bölüm
                      </option>
                      <option>Bölüm 1</option>
                      <option>Bölüm 2</option>
                      <option>Bölüm 3</option>
                      <option>Bölüm 4</option>
                      <option>Bölüm 5</option>
                    </select>
                    <select className="intro_select intro_input" required defaultValue="">
                      <option disabled value="">
                        Doktor
                      </option>
                      <option>Doktor 1</option>
                      <option>Doktor 2</option>
                      <option>Doktor 3</option>
                      <option>Doktor 4</option>
                      <option>Doktor 5</option>
                    </select>
                    <input
                      type="text"
                      id="datepicker"
                      className="intro_input datepicker"
                      placeholder="Tarih"
                      required="required"
                    />
                  </div>
                  <button className="button button_1 intro_button trans_200">Onayla</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Call to action */}
      <div className="cta">
        <div className="container">
          <div className="row">
            <div className="col">
              <div className="cta_container d-flex flex-lg-row flex-column align-items-lg-center align-items-start justify-content-start">
                <div className="cta_content">
                  <div className="cta_text">Herhangi bir konuda hemen bilgi almak için</div>
                  <div className="cta_title">Bizi arayın</div>
                </div>
                <div className="cta_phone ml-lg-auto">444 6 112</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <ServicesComponent />
      {/* Extra */}
      <div className="extra">
        <div
          className="parallax_background parallax-window"
          data-parallax="scroll"
          data-image-src="/assets/images/extra.jpg"
          data-speed="0.8"
        />
        <div className="container">
          <div className="row">
            <div className="col">
              <div className="extra_container d-flex flex-row align-items-start justify-content-end">
                <div className="extra_content">
                  <div className="extra_disc d-flex flex-row align-items-end justify-content-start">
                    <div>Hastahanemizde</div>
                  </div>
                  <div className="extra_title">Göz Estetiği</div>
                  <div className="extra_text">
                    <div>Hizmetimiz başlamıştır</div>
                    <br />
                  </div>
                  <div className="button button_1 extra_link trans_200">
                    <Link to={CONTACT}>İletişim</Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Newsletter />
    </>
  );
};

export default Home;
