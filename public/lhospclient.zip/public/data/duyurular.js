{
    "0": {
      "date": { "day": 19, "month": "Aralık", "year": "2019" },
      "image": "/assets/images/blog_1.jpg",
      "author": "Dr. John Doe",
      "topic": "Surgery",
      "title": "Lorem ipsum dolor sit amet consectetur.",
      "text":
        "Odio ultrices ut. Etiam ac erat ut enim maximus accumsan vel ac nisl. Duis feugiat bibendum orci, non elementum urna. Cras sit amet sapien aliquam, fermentum dolor non, blandit purus. Donec blandit purus vitae eros fringilla accumsan. Nunc feugiat purus et posuere ornare. Vivamus molestie sem pretium ligula efficitur, vitae auctor tortor vestibulum. Ut interdum ante neque, sed vestibulum lorem dictum quis."
    },
    "1": {
      "date": { "day": 19, "month": "Aralık", "year": "2019" },
      "image": "/assets/images/blog_1.jpg",
      "author": "Dr. John Doe",
      "topic": "Surgery",
      "title": "Lorem ipsum dolor sit amet consectetur.",
      "text":
        "Odio ultrices ut. Etiam ac erat ut enim maximus accumsan vel ac nisl. Duis feugiat bibendum orci, non elementum urna. Cras sit amet sapien aliquam, fermentum dolor non, blandit purus. Donec blandit purus vitae eros fringilla accumsan. Nunc feugiat purus et posuere ornare. Vivamus molestie sem pretium ligula efficitur, vitae auctor tortor vestibulum. Ut interdum ante neque, sed vestibulum lorem dictum quis."
    },
    "2": {
      "date": { "day": 19, "month": "Aralık", "year": "2019" },
      "image": "/assets/images/blog_1.jpg",
      "author": "Dr. John Doe",
      "topic": "Surgery",
      "title": "Lorem ipsum dolor sit amet consectetur.",
      "text":
        "Odio ultrices ut. Etiam ac erat ut enim maximus accumsan vel ac nisl. Duis feugiat bibendum orci, non elementum urna. Cras sit amet sapien aliquam, fermentum dolor non, blandit purus. Donec blandit purus vitae eros fringilla accumsan. Nunc feugiat purus et posuere ornare. Vivamus molestie sem pretium ligula efficitur, vitae auctor tortor vestibulum. Ut interdum ante neque, sed vestibulum lorem dictum quis."
    }
}