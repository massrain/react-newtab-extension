{
    "0":{
      "img": "/assets/images/doctors/kadiraydogmus.jpg",
      "name": "Dr. Kadir AYDOĞMUŞ",
      "birim": "Yabancı Hasta Birimi",
      "unvan": "Başhekim"
    },
    "1":{
      "img": "/assets/images/doctors/mustafakorucu.jpg",
      "name": "Op. Dr. Mustafa Korucu",
      "birim": "Beyin ve Sinir Cerrahi",
      "unvan": ""
    },
    "2":{
      "img": "/assets/images/doctors/osmannuribuyuker.jpg",
      "name": "Op. Dr. Osman Nuri Büyüker",
      "birim": "Çocuk Cerrahisi",
      "unvan": ""
    },
    "3":{
      "img": "/assets/images/doctors/huseyinhelvaci.jpg",
      "name": "Uz. Dr. Hüseyin Helvacı",
      "birim": "Çocuk Doktoru",
      "unvan": ""
    },
    "4":{
      "img": "/assets/images/doctors/yaseminonursalhelvaci.jpg",
      "name": "Uz. Dr. Yasemin Onursal Helvacı",
      "birim": "Çocuk Doktoru",
      "unvan": ""
    },
    "5":{
      "img": "/assets/images/doctors/behzatguler.jpg",
      "name": "Uz. Dr. Behzat Güler",
      "birim": "Dahiliye",
      "unvan": ""
    },
    "6": {
      "img": "/assets/images/doctors/servetemeksiz.jpg",
      "name": "Op. Dr. Servet Emeksiz",
      "birim": "Genel Cerrahi",
      "unvan": ""
    },
    "8":{
      "img": "/assets/images/doctors/ahmetguldas.jpg",
      "name": "Op. Dr. Ahmet Güldaş",
      "birim": "Kadın Hastalıkları ve Doğum",
      "unvan": ""
    },
    "9":{
      "img": "/assets/images/doctors/nacigemici.jpg",
      "name": "Uz. Dr. Naci Gemici",
      "birim": "Nöroloji",
      "unvan": ""
    },
    "10":{
      "img": "/assets/images/doctors/alperarikan.jpg",
      "name": "Op. Dr. Alper Arıkan",
      "birim": "Ortopedi",
      "unvan": ""
    },
    "11":{
      "img": "/assets/images/doctors/mertkeskinbora.jpeg",
      "name": "Op. Dr. Mert Keskin Bora",
      "birim": "Ortopedi",
      "unvan": ""
    },
    "12":{
      "img": "/assets/images/doctors/mehmetmunduz.jpg",
      "name": "Uz. Dr. Mehmet Munduz",
      "birim": "Radyoloji",
      "unvan": ""
    },
    "13": {
      "img": "/assets/images/doctors/nailkocer.jpg",
      "name": "Uz. Dr. Nail Koçer",
      "birim": "Radyoloji",
      "unvan": ""
    },
    "14": {
      "img": "/assets/images/doctors/jasurdjamilov.jpg",
      "name": "Op. Dr. Jasur Djamilov",
      "birim": "Üroloji",
      "unvan": ""
    }
}