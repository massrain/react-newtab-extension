export const HOME = "/";
export const CONTACT = "/iletisim";
export const DOCTORS = "/hekimlerimiz";
export const BLOG = "/blog";

export const SERVICES = "/birimlerimiz";

export const SERVICES_ICHASTALIKLARI = "/birimlerimiz/ichastaliklari";
export const SERVICES_BEYINVESINIRCERRAHISI = "/birimlerimiz/beyinvesinircerrahisi";
export const SERVICES_UROLOJI = "/birimlerimiz/uroloji";
export const SERVICES_ORTOPEDIVETRAVMATOLOJI = "/birimlerimiz/ortopedivetravmatoloji";
export const SERVICES_GOZHASTALIKLARI = "/birimlerimiz/gozhastaliklari";
export const SERVICES_COCUKHASTALIKLARI = "/birimlerimiz/cocukhastaliklari";
export const SERVICES_KULAKBURUNBOGAZ = "/birimlerimiz/kulakburunbogaz";
export const SERVICES_DIS = "/birimlerimiz/dis";
export const SERVICES_GENELCERRAHI = "/birimlerimiz/genelcerrahi";
export const SERVICES_ANASTEZIVEREANIMASYON = "/birimlerimiz/anastezivereanimasyon";
export const SERVICES_KADINDOGUM = "/birimlerimiz/kadindogum";
export const SERVICES_ACILSERVIS = "/birimlerimiz/acilservis";
export const SERVICES_YABANCIHASTALIKLAR = "/birimlerimiz/yabancihastaliklar";
export const SERVICES_RADYOLOJI = "/birimlerimiz/radyoloji";
export const SERVICES_BIYOKIMYA = "/birimlerimiz/biyokimya";
export const SERVICES_COCUKCERRAHISI = "/birimlerimiz/cocukcerrahisi";
export const SERVICES_FTR = "/birimlerimiz/ftr";
export const SERVICES_KARDIYOLOJI = "/birimlerimiz/kardiyoloji";
export const SERVICES_BESLENMEVEDIYET = "/birimlerimiz/beslenmevediyet";
export const SERVICES_GOGUSHASTALIKLARI = "/birimlerimiz/gogushastaliklari";
