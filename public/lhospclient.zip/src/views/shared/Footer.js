import React from "react";
import { Link } from "react-router-dom";
import { HOME } from "../../helpers/routes";
const Footer = () => {
  return (
    <>
      {/* Footer */}
      <footer className="footer">
        <div className="footer_content">
          <div className="container">
            <div className="row">
              <div className="col-12 text-center">
                <a href="http://www.kanver.org" target="_blank" rel="noopener noreferrer">
                  <img alt="Kan" className="img-fluid" height={90} width={728} src="/assets/images/new/kanver.gif" />
                </a>
              </div>
            </div>
            <div className="row">
              {/* Footer About */}
              <div className="col-lg-4 footer_col">
                <div className="footer_about">
                  <div className="footer_logo">
                    <Link to={HOME}>
                      <img src="/assets/images/letoonlogo.png" alt="" className="img-fluid" />
                    </Link>
                  </div>
                  <div className="footer_about_text">
                    <p>Fethiye'nin ilk özel hastanesi.</p>
                    <p>Sağlığınız bizim için önemlidir.</p>
                  </div>
                </div>
              </div>
              {/* Footer Contact Info */}
              <div className="col-lg-4 footer_col">
                <div className="footer_contact">
                  <div className="footer_title">İletişim bilgileri</div>
                  <ul className="contact_list">
                    <li>444 6 112</li>
                    <li>info@letoonhospital.com.tr</li>
                    <li>www.letoonhospital.com.tr</li>
                  </ul>
                </div>
              </div>
              {/* Footer Locations */}
              <div className="col-lg-4 footer_col">
                <div className="footer_location">
                  <div className="footer_title">Konum</div>
                  <ul className="locations_list">
                    <li>
                      <div className="location_title">Fethiye/ MUĞLA</div>
                      <div className="location_text">Pazaryeri Mahallesi Şehit Hasan Küçükçoban Cad. No: 22 48300</div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
};

export default Footer;
