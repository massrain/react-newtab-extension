import React from "react";
import { Link, NavLink } from "react-router-dom";
import { HOME, CONTACT, DOCTORS, SERVICES } from "../../helpers/routes";

const Navbar = () => {
  return (
    <>
      <div className="super_container">
        {/* Header */}
        <header className="header trans_400">
          <div className="header_content d-flex flex-row align-items-center jusity-content-start trans_400">
            {/* Logo */}
            <div className="logo">
              <Link to={HOME}>
                <img src="./images/letoonlogo.png" alt="" className="img-fluid" />
              </Link>
            </div>
            {/* Main Navigation */}
            <nav className="main_nav">
              <ul className="d-flex flex-row align-items-center justify-content-start">
                <li>
                  <NavLink exact to={HOME} activeClassName="custom-selected-link">
                    Anasayfa
                  </NavLink>
                </li>
                <li>
                  <NavLink exact to={HOME} activeClassName="custom-selected-link">
                    Kurumsal
                  </NavLink>
                </li>
                <li>
                  <NavLink exact to={SERVICES} activeClassName="custom-selected-link">
                    Birimlerimiz
                  </NavLink>
                </li>
                <li>
                  <NavLink exact to={DOCTORS} activeClassName="custom-selected-link">
                    Hekimlerimiz
                  </NavLink>
                </li>
                <li>
                  <NavLink exact to={CONTACT} activeClassName="custom-selected-link">
                    İletişim
                  </NavLink>
                </li>
              </ul>
            </nav>
            <div className="header_extra d-flex flex-row align-items-center justify-content-end ml-auto">
              {/* Work Hourse */}
              {/* Appointment Button */}
              <div className="button button_1 header_button">
                <a href="https://gothru.co/PqJckbdNz?index=scene_0&hlookat=263&vlookat=5&fov=100">Sanal Tur</a>
              </div>
              {/* Header Social */}
              <div className="social header_social">
                <ul className="d-flex flex-row align-items-center justify-content-start">
                  <li>
                    <a href="https://www.youtube.com/c/LetoonhospitalTr">
                      <i className="fa fa-youtube" />
                    </a>
                  </li>
                  <li>
                    <a href="https://www.facebook.com/ozelletoonhospital">
                      <i className="fa fa-facebook" />
                    </a>
                  </li>
                  <li>
                    <a href="https://twitter.com/letoonhospital">
                      <i className="fa fa-twitter" />
                    </a>
                  </li>
                </ul>
              </div>
              {/* Hamburger */}
              <div className="hamburger">
                <i className="fa fa-bars" />
              </div>
            </div>
          </div>
        </header>
        {/* Menu */}
        <div className="menu_overlay trans_400" />
        <div className="menu trans_400">
          <div className="menu_close_container">
            <div className="menu_close">
              <div />
              <div />
            </div>
          </div>
          <nav className="menu_nav">
            <ul>
              <li>
                <NavLink to={HOME} activeClassName="custom-selected-link">
                  Anasayfa
                </NavLink>
              </li>
              <li>
                <NavLink to={HOME} activeClassName="custom-selected-link">
                  Kurumsal
                </NavLink>
              </li>
              <li>
                <NavLink to={HOME} activeClassName="custom-selected-link">
                  Birimlerimiz
                </NavLink>
              </li>
              <li>
                <NavLink to={HOME} activeClassName="custom-selected-link">
                  Hekimlerimiz
                </NavLink>
              </li>
              <li>
                <NavLink to={HOME} activeClassName="custom-selected-link">
                  İletişim
                </NavLink>
              </li>
            </ul>
          </nav>
          <div className="social menu_social">
            <ul className="d-flex flex-row align-items-center justify-content-start">
              <li>
                <a href="https://www.youtube.com/c/LetoonhospitalTr">
                  <i className="fa fa-youtube" />
                </a>
              </li>
              <li>
                <a href="https://www.facebook.com/ozelletoonhospital">
                  <i className="fa fa-facebook" />
                </a>
              </li>
              <li>
                <a href="https://twitter.com/letoonhospital">
                  <i className="fa fa-twitter" />
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
};

export default Navbar;
