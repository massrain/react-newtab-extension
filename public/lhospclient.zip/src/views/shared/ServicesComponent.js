import React from "react";

const ServicesComponent = () => {
  return (
    <>
      {/* Services */}
      <div className="services">
        <div className="container">
          <div className="row">
            <div className="col text-center">
              <div className="section_title_container">
                <div className="section_subtitle">Letoon Hastahanesi</div>
                <div className="section_title">
                  <h2>Birimlerimiz</h2>
                </div>
              </div>
            </div>
          </div>
          <div className="row services_row">
            {/* Service */}
            <SingleService icon={"/assets/images/icon_1.svg"} title={"İç hastalıkları"} />
            <SingleService icon={"/assets/images/icon_2.svg"} title={"Beyin ve Sinir Cerrahisi"} />
            <SingleService icon={"/assets/images/icon_3.svg"} title={"Üroloji"} />
            <SingleService icon={"/assets/images/icon_4.svg"} title={"Ortopedi ve Travmatoloji"} />
            <SingleService icon={"/assets/images/icon_5.svg"} title={"Göz Hastalıkları"} />
            <SingleService icon={"/assets/images/icon_6.svg"} title={"Çocuk Hastalıkları"} />
            <SingleService icon={"/assets/images/icon_7.svg"} title={"Kulak Burun Boğaz"} />
            <SingleService icon={"/assets/images/icon_8.svg"} title={"Diş"} />
            <SingleService icon={"/assets/images/icon_1.svg"} title={"Genel Cerrahi"} />
            <SingleService icon={"/assets/images/icon_2.svg"} title={"Anastezi ve Reanimasyon"} />
            <SingleService icon={"/assets/images/icon_3.svg"} title={"Kadın Doğum"} />
            <SingleService icon={"/assets/images/icon_4.svg"} title={"Acil Servis"} />
            <SingleService icon={"/assets/images/icon_5.svg"} title={"Yabancı Hastalıklar"} />
            <SingleService icon={"/assets/images/icon_6.svg"} title={"Radyoloji"} />
            <SingleService icon={"/assets/images/icon_7.svg"} title={"Biyokimya"} />
            <SingleService icon={"/assets/images/icon_8.svg"} title={"Çocuk Cerrahisi"} />
            <SingleService icon={"/assets/images/icon_1.svg"} title={"F. T. R"} />
            <SingleService icon={"/assets/images/icon_2.svg"} title={"Kardiyoloji"} />
            <SingleService icon={"/assets/images/icon_3.svg"} title={"Beslenme ve Diyet"} />
            <SingleService icon={"/assets/images/icon_4.svg"} title={"Göğüs Hastalıkları"} />
          </div>
        </div>
      </div>
    </>
  );
};

export default ServicesComponent;

const SingleService = props => (
  <div className="col-xl-4 col-md-6 service_col">
    <div className="service text-center">
      <div className="service">
        <div className="icon_container d-flex flex-column align-items-center justify-content-center ml-auto mr-auto">
          <div className="icon">
            <img src={props.icon} alt="" />
          </div>
        </div>
        <div className="service_title">{props.title}</div>
      </div>
    </div>
  </div>
);
