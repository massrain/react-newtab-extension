import React from "react";
import Sidebar from "./Sidebar";

const KalitePolitikasi = () => {
  return (
    <>
      <div className="services mt-5">
        <div className="container">
          <div className="row">
            <div className="col-9">
              <div className="row">
                <div className="col text-center">
                  <div className="section_title_container text-left">
                    <div className="section_title">
                      <h2>Kalite Politikamız</h2>
                    </div>
                    <p>Kalite Yönetim Sistemimiz, uluslararası akreditasyon ve ISO standartları esas alınarak oluşturulmuştur. </p>
                    <p>Bizim İçin:</p>
                    <p>
                      Hasta ve çalışanlarımızın memnuniyeti'ne odaklı hizmet anlayışını oluşturmak, Sürekli ölçme ve iyileştirme
                      mekanizmaları kullanarak örnek bir yönetim ve işletim sistemi kurmak, Mükemmel sağlık hizmetini, kaliteden ödün
                      vermeden uygun fiyatlarla sunmak, Kendimizi sürekli eğitmek ve geliştirmek, yönetim felsefemizin ve kalite
                      politikamızın temel ilkeleridir.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-3">
              <div className="row services_row">
                <Sidebar />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default KalitePolitikasi;
