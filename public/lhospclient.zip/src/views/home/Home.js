import React, { useEffect } from "react";
import { useHistory } from "react-router-dom";
import ServicesComponent from "../shared/ServicesComponent";
import Newsletter from "../shared/Newsletter";
import { CONTACT, BLOG } from "../../helpers/routes";
import { Link } from "react-router-dom";

import "../../styles/main_styles.css";
import "../../styles/responsive.css";

const Home = () => {
  let history = useHistory();

  useEffect(() => {
    const script = document.createElement("script");
    script.src = "/assets/js/custom.js";
    script.async = true;
    document.body.appendChild(script);

    const script2 = document.createElement("script");
    script2.src = "/assets/plugins/parallax-js-master/parallax.min.js";
    script2.async = true;
    document.body.appendChild(script2);
    return () => {
      //n document.body.removeChild(script);
      document.body.removeChild(script2);
    };
  }, []);

  const pushToBlog = () => {
    history.push(BLOG);
  };
  return (
    <>
      {/* Home */}
      <div className="home">
        {/* Home Slider */}
        <div className="home_slider_container">
          <div className="owl-carousel owl-theme home_slider">
            {/* Slide */}
            <div className="owl-item">
              <div className="background_image" style={{ backgroundImage: "url('/assets/images/new/background_1.jpeg')" }} />
              <div className="home_container">
                <div className="container">
                  <div className="row">
                    <div className="col"></div>
                  </div>
                </div>
              </div>
            </div>
            {/* Slide */}
            <div className="owl-item">
              <div className="background_image" style={{ backgroundImage: "url(/assets/images/new/background_2.jpeg)" }} />
              <div className="home_container">
                <div className="container">
                  <div className="row">
                    <div className="col"></div>
                  </div>
                </div>
              </div>
            </div>
            {/* Slide */}
            <div className="owl-item">
              <div className="background_image" style={{ backgroundImage: "url(assets/images/new/background_3.jpeg)" }} />
              <div className="home_container">
                <div className="container">
                  <div className="row">
                    <div className="col"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* Home Slider Dots */}
          <div className="home_slider_dots">
            <ul id="home_slider_custom_dots" className="home_slider_custom_dots d-flex flex-row align-items-center justify-content-start">
              <li className="home_slider_custom_dot trans_200 active" />
              <li className="home_slider_custom_dot trans_200" />
              <li className="home_slider_custom_dot trans_200" />
            </ul>
          </div>
        </div>
      </div>
      {/* Intro */}
      <div className="intro">
        <div className="container">
          <div className="row">
            {/* Intro Content */}
            <div className="col-lg-6 intro_col">
              <div className="intro_content">
                <div className="section_title_container">
                  <div className="section_subtitle">Özel Letoon Hastanesi</div>
                  <div className="section_title">
                    <h2>Hastanemize hoş geldiniz.</h2>
                  </div>
                </div>
              </div>
            </div>
            {/* Intro Form */}
            <div className="col-lg-6 intro_col">
              <div className="intro_form_container p-5">
                <button className="button button_1 intro_button trans_200" onClick={pushToBlog}>
                  Duyurular
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Call to action */}
      <div className="cta">
        <div className="container">
          <div className="row">
            <div className="col">
              <div className="cta_container d-flex flex-lg-row flex-column align-items-lg-center align-items-start justify-content-start">
                <div className="cta_content">
                  <div className="cta_title">Online İşlemler</div>
                </div>
                <div
                  className="cta_phone ml-lg-auto cursor--pointer"
                  onClick={() => window.open("http://212.156.247.126/MW_Web/labradlogin.aspx")}
                >
                  Laboratuar Sonuç
                </div>
                <div
                  className="cta_phone ml-lg-auto cursor--pointer"
                  onClick={() => window.open("http://212.156.247.126/MW_Web/newappointment.aspx")}
                >
                  Online Randevu
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <ServicesComponent />
      {/* Extra */}
      <div className="extra">
        <div
          className="parallax_background parallax-window"
          data-parallax="scroll"
          data-image-src="/assets/images/extra.jpg"
          data-speed="0.8"
        />
        <div className="container">
          <div className="row">
            <div className="col">
              <div className="extra_container d-flex flex-row align-items-start justify-content-end">
                <div className="extra_content">
                  <div className="extra_disc d-flex flex-row align-items-end justify-content-start">
                    <div>Hastanemizde</div>
                  </div>
                  <div className="extra_title">Göz Estetiği</div>
                  <div className="extra_text">
                    <div>Hizmetimiz başlamıştır</div>
                    <br />
                  </div>
                  <div className="button button_1 extra_link trans_200">
                    <Link to={CONTACT}>İletişim</Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Newsletter />
    </>
  );
};

export default Home;

/* http://212.156.247.126/MW_Web/newappointment.aspx */
