import React from "react";

const BlogSingle = props => {
  const colorblue = {
    color: "#57ccc3",
    fontSize: "14px",
    fontWeight: 600
  };
  const blogtitle = {
    fontSize: "30px",
    fontWeight: 600,
    color: "#404040",
    lineHeight: 1.2
  };
  return (
    <>
      <div className="blog_post">
        <div className="blog_post_image">
          <img src={props.data.image} alt="" />
        </div>
        <div className="blog_post_date d-flex flex-column align-items-center justify-content-center">
          <div className="date_day">{props.data.date.day}</div>
          <div className="date_month">{props.data.date.month}</div>
          <div className="date_year">{props.data.date.year}</div>
        </div>
        <div className="blog_post_title">
          <span style={blogtitle}>{props.data.title}</span>
        </div>
        <div className="blog_post_info">
          <ul className="d-flex flex-row align-items-center justify-content-center">
            <li>
              <span style={colorblue}>{props.data.author}</span> tarafından
            </li>
            <li>
              <span style={colorblue}>{props.data.topic}</span> hakkında
            </li>
          </ul>
        </div>
        <div className="blog_post_text text-center">
          <p>{props.data.text}</p>
        </div>
      </div>
    </>
  );
};

export default BlogSingle;
