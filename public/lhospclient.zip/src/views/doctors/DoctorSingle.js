import React from "react";

const DoctorSingle = props => {
  return (
    <>
      <div className="col-lg-4 team_col">
        <div className="team_item text-center d-flex flex-column aling-items-center justify-content-end">
          <div className="team_image">
            <img src={props.data.img} alt="" />
          </div>
          <div className="team_content text-center">
            <div className="team_name">
              <a href="#">{props.data.name}</a>
            </div>
            <div className="team_title">{props.data.birim}</div>
            <div className="team_text">
              <p>{props.data.unvan}</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default DoctorSingle;