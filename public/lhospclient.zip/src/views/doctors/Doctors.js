import React from "react";
import "../../styles/about.css";
import "../../styles/about_responsive.css";

const Doctors = () => {
  return (
    <>
      {/* Home */}
      <div className="home d-flex flex-column align-items-start justify-content-end">
        {/* <div class="background_image" style="background-image:url(images/about.jpg)"></div> */}
        <div
          className="parallax_background parallax-window"
          data-parallax="scroll"
          data-image-src="/assets/images/about.jpg"
          data-speed="0.8"
        />
        <div className="home_overlay">
          <img src="/assets/images/home_overlay.png" alt="" />
        </div>
        <div className="home_container">
          <div className="container">
            <div className="row">
              <div className="col">
                <div className="home_content">
                  <div className="home_title">Hekimlerimiz</div>
                  <div className="home_text">Hastahanemiz bünyesindeki, alanında uzman kadromuz</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Team */}
      <div className="team">
        <div className="container">
          <div className="row team_row">
            {/* Team Item */}
            <div className="col-lg-4 team_col">
              <div className="team_item text-center d-flex flex-column aling-items-center justify-content-end">
                <div className="team_image">
                  <img src="/assets/images/team_1.jpg" alt="" />
                </div>
                <div className="team_content text-center">
                  <div className="team_name">
                    <a href="#">Dr. Kadir AYDOĞMUŞ</a>
                  </div>
                  <div className="team_title">Yabancı Hasta Birimi</div>
                  <div className="team_text">
                    <p>Başhekim</p>
                  </div>
                </div>
              </div>
            </div>
            {/* Team Item */}
            <div className="col-lg-4 team_col">
              <div className="team_item text-center d-flex flex-column aling-items-center justify-content-end">
                <div className="team_image">
                  <img src="/assets/images/team_2.jpg" alt="" />
                </div>
                <div className="team_content text-center">
                  <div className="team_name">
                    <a href="#">Dyt. Şule ŞAHİN</a>
                  </div>
                  <div className="team_title">Beslenme ve Diyet</div>
                  <div className="team_text">
                    <p>---</p>
                  </div>
                </div>
              </div>
            </div>
            {/* Team Item */}
            <div className="col-lg-4 team_col">
              <div className="team_item text-center d-flex flex-column aling-items-center justify-content-end">
                <div className="team_image">
                  <img src="/assets/images/team_3.jpg" alt="" />
                </div>
                <div className="team_content text-center">
                  <div className="team_name">
                    <a href="#">Dr. Tareq M.A A. RYALAT</a>
                  </div>
                  <div className="team_title">Acil Servis</div>
                  <div className="team_text">
                    <p>---</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Doctors;
