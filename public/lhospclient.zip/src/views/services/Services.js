import React from "react";
import ServicesComponent from "../shared/ServicesComponent";

const Services = () => {
  return (
    <>
      <div>
        {/* Home */}
        <div className="home d-flex flex-column align-items-start justify-content-end">
          <div
            className="parallax_background parallax-window"
            data-parallax="scroll"
            data-image-src="images/services.jpg"
            data-speed="0.8"
          />
          <div className="home_overlay">
            <img src="images/home_overlay.png" alt="" />
          </div>
          <div className="home_container">
            <div className="container">
              <div className="row">
                <div className="col">
                  <div className="home_content">
                    <div className="home_title">Services</div>
                    <div className="home_text">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Services */}
        <ServicesComponent />
      </div>
    </>
  );
};

export default Services;
