import React from "react";
import ServicesComponent from "../shared/ServicesComponent";
import { Route, Switch } from "react-router-dom";
import { SERVICES_ICHASTALIKLARI, SERVICES_BEYINVESINIRCERRAHISI, SERVICES_UROLOJI, SERVICES_ORTOPEDIVETRAVMATOLOJI, SERVICES_GOZHASTALIKLARI, SERVICES_COCUKHASTALIKLARI, SERVICES_KULAKBURUNBOGAZ, SERVICES_DIS, SERVICES_GENELCERRAHI, SERVICES_ANASTEZIVEREANIMASYON, SERVICES_KADINDOGUM, SERVICES_ACILSERVIS, SERVICES_YABANCIHASTALIKLAR, SERVICES_RADYOLOJI, SERVICES_BIYOKIMYA, SERVICES_COCUKCERRAHISI, SERVICES_FTR, SERVICES_KARDIYOLOJI, SERVICES_BESLENMEVEDIYET, SERVICES_GOGUSHASTALIKLARI, SERVICES } from "../../helpers/routes";
import ServicesSingle from "./ServicesSingle";

const Services = () => {
  return (
    <>
      {/* Services */}
      
        <Switch>
          <Route exact path={SERVICES}><ServicesComponent /></Route>
          <Route exact path={SERVICES_ICHASTALIKLARI}><ServicesSingle name="SERVICES_ICHASTALIKLARI"/></Route>
          <Route exact path={SERVICES_BEYINVESINIRCERRAHISI}><ServicesSingle name="SERVICES_BEYINVESINIRCERRAHISI"/></Route>
          <Route exact path={SERVICES_UROLOJI}><ServicesSingle name="SERVICES_UROLOJI"/></Route>
          <Route exact path={SERVICES_ORTOPEDIVETRAVMATOLOJI}><ServicesSingle name="SERVICES_ORTOPEDIVETRAVMATOLOJI"/></Route>
          <Route exact path={SERVICES_GOZHASTALIKLARI}><ServicesSingle name="SERVICES_GOZHASTALIKLARI"/></Route>
          <Route exact path={SERVICES_COCUKHASTALIKLARI}><ServicesSingle name="SERVICES_COCUKHASTALIKLARI"/></Route>
          <Route exact path={SERVICES_KULAKBURUNBOGAZ}><ServicesSingle name="SERVICES_KULAKBURUNBOGAZ"/></Route>
          <Route exact path={SERVICES_DIS}><ServicesSingle name="SERVICES_DIS"/></Route>
          <Route exact path={SERVICES_GENELCERRAHI}><ServicesSingle name="SERVICES_GENELCERRAHI"/></Route>
          <Route exact path={SERVICES_ANASTEZIVEREANIMASYON}><ServicesSingle name="SERVICES_ANASTEZIVEREANIMASYON"/></Route>
          <Route exact path={SERVICES_KADINDOGUM}><ServicesSingle name="SERVICES_KADINDOGUM"/></Route>
          <Route exact path={SERVICES_ACILSERVIS}><ServicesSingle name="SERVICES_ACILSERVIS"/></Route>
          <Route exact path={SERVICES_YABANCIHASTALIKLAR}><ServicesSingle name="SERVICES_YABANCIHASTALIKLAR"/></Route>
          <Route exact path={SERVICES_RADYOLOJI}><ServicesSingle name="SERVICES_RADYOLOJI"/></Route>
          <Route exact path={SERVICES_BIYOKIMYA}><ServicesSingle name="SERVICES_BIYOKIMYA"/></Route>
          <Route exact path={SERVICES_COCUKCERRAHISI}><ServicesSingle name="SERVICES_COCUKCERRAHISI"/></Route>
          <Route exact path={SERVICES_FTR}><ServicesSingle name="SERVICES_FTR"/></Route>
          <Route exact path={SERVICES_KARDIYOLOJI}><ServicesSingle name="SERVICES_KARDIYOLOJI"/></Route>
          <Route exact path={SERVICES_GOGUSHASTALIKLARI}><ServicesSingle name="SERVICES_GOGUSHASTALIKLARI"/></Route>
          <Route exact path={SERVICES_BESLENMEVEDIYET}><ServicesSingle name="SERVICES_BESLENMEVEDIYET"/></Route>
        </Switch>

    </>
  );
};

export default Services;


