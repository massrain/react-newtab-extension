import React, { useEffect } from "react";
import "../../styles/contact.css";
import "../../styles/contact_responsive.css";

import overlay from "../../imports/home_overlay.png";

const Contact = () => {
  useEffect(() => {
    const script = document.createElement("script");
    script.src = "/assets/js/contact.js";
    script.async = true;
    document.body.appendChild(script);

    const script2 = document.createElement("script");
    script2.src = "/assets/plugins/parallax-js-master/parallax.min.js";
    script2.async = true;
    document.body.appendChild(script2);

    return () => {
      document.body.removeChild(script);
      document.body.removeChild(script2);
    };
  }, []);
  return (
    <>
      {/* Home */}
      <div className="home d-flex flex-column align-items-start justify-content-end">
        <div
          className="parallax_background parallax-window"
          data-parallax="scroll"
          data-image-src="/assets/images/contact.jpg"
          data-speed="0.8"
        />
        <div className="home_overlay">
          <img src={overlay} alt="" />
        </div>
        <div className="home_container">
          <div className="container">
            <div className="row">
              <div className="col">
                <div className="home_content">
                  <div className="home_title">İletişim</div>
                  <div className="home_text">7/24 saat bize ulaşabileceğiniz yollar..</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Contact */}
      <div className="contact">
        <div className="container">
          <div className="row justify-content-center text-center">
            {/* Contact Form */}
{/*             <div className="col-lg-6">
              <div className="contact_form_container">
                <div className="contact_form_title">İletişim Formu</div>
                <form action="http://212.156.247.126/randevu/randevu.aspx" target="_blank" className="intro_form" id="intro_form">
                  <div
                    className="d-flex flex-row align-items-start justify-content-between flex-wrap"
                    style={{ width: "calc((100% - 15px))" }}
                  >
                    <input type="text" className="intro_input" placeholder="İsminiz" />
                    <input type="email" className="intro_input" placeholder="Mail adresi" />
                    <input type="tel" className="intro_input" placeholder="Telefon numaranız" />
                    <select className="intro_select intro_input" defaultValue="">
                      <option disabled value="">
                        Mesaj türü
                      </option>
                      <option>Teşekkür</option>
                      <option>Görüş / Öneri</option>
                      <option>Şikayet</option>
                    </select>
                    <textarea className="intro_input" cols="30" rows="10" placeholder="Mesaj" style={{ width: "calc((100% - 15px))" }}></textarea>
                  </div>
                  <button className="button button_1 intro_button trans_200">Onayla</button>
                </form>
              </div>
            </div>
           */}  {/* Contact Content */}
            <div className="col-lg-5 offset-lg-1 contact_col">
              <div className="contact_content">
                <div className="contact_content_title">İletişime geçin</div>
                <div className="contact_content_text">
                  <p>
                  Not: İş başvurularınızı info@letoonhospital.com.tr adresine, öz geçmişinizi yollayarak yapabilirsiniz.
                  </p>
                </div>
                <div className="direct_line d-flex flex-row align-items-center justify-content-start">
                  <div className="direct_line_title text-center">Telefon</div>
                  <div className="direct_line_num text-center">444 6 112</div>
                </div>
                <div className="contact_info">
                  <ul>
                    <li className="d-flex flex-row align-items-start justify-content-start">
                      <div>Adres</div>
                      <div>Pazaryeri Mahallesi Şehit Hasan Küçükçoban Cad. No: 22 48300 Fethiye/ MUĞLA</div>
                    </li>
                    <li className="d-flex flex-row align-items-start justify-content-start">
                      <div>Faks</div>
                      <div>+90 252 646 5157</div>
                    </li>
                    <li className="d-flex flex-row align-items-start justify-content-start">
                      <div>E-mail</div>
                      <div>info@letoonhospital.com.tr</div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="row google_map_row">
            <div className="col justify-content-center text-center">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12807.31449507866!2d29.144446284594718!3d36.630511595095136!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xf11e1fef99fb4c4!2s%C3%96zel%20Letoon%20Hospital!5e0!3m2!1str!2str!4v1578243808358!5m2!1str!2str"
                width="600"
                height="450"
                frameBorder="0"
                style={{ border: 0 }}
                allowFullScreen=""
                title="letoon google map harita"
              ></iframe>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Contact;
