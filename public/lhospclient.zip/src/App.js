import React from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Navbar from "./views/shared/Navbar";
import Home from "./views/home/Home";
import Footer from "./views/shared/Footer";
import { HOME } from "./helpers/routes";

function App() {
  return (
    <>
      <Router>
        <Navbar />
        <Switch>
          <Route exact path={HOME}>
            <Home />
          </Route>
        </Switch>
        <Footer />
      </Router>
    </>
  );
}

export default App;
