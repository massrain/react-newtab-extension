import React from "react";
import Mainpage from "./views/mainpage/Mainpage";

import { Route, Switch } from "react-router-dom";
import Search from "./views/search/Search";
import ScrollToTop from "./views/shared/ScrollToTop";

const App = () => {
  return (
    <>
      <ScrollToTop>
        <Switch>
          <Route exact path={"/"} component={Mainpage} />
          <Route exact path={"/search"} component={Search} />
        </Switch>
      </ScrollToTop>
    </>
  );
};

export default App;

//key: AIzaSyDoMZ2XnwiIeumO6-xgCcopHTVwfxVmM80
//cx: 003014573317456829330:tqxdlhxphtr
//https://www.googleapis.com/customsearch/v1?key=INSERT_YOUR_API_KEY&cx=017576662512468239146:omuauf_lfve&q=lectures
