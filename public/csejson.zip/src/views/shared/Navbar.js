/* eslint-disable jsx-a11y/anchor-is-valid */
import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav className="navbar navbar-expand-md navbar-dark bg-primary">
      <Link className="navbar-brand" to="/">
        Addiyos Search
      </Link>
      <button className="navbar-toggler" data-toggle="collapse" data-target="#navbar1">
        <span className="navbar-toggler-icon"></span>
      </button>

      <div className="collapse navbar-collapse" id="navbar1">
        <ul className="navbar-nav ml-auto">
          <li className="nav-item active">
            <Link className="nav-link">Anasayfa</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link disabled">Hakkında</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link disabled">İletişim</Link>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
