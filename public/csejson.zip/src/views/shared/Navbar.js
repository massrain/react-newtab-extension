/* eslint-disable jsx-a11y/anchor-is-valid */
import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav className="navbar navbar-expand-md navbar-dark bg-primary">
      <Link className="navbar-brand" to="/">
        Search
      </Link>
      <button className="navbar-toggler" data-toggle="collapse" data-target="#navbar1">
        <span className="navbar-toggler-icon"></span>
      </button>

      <div className="collapse navbar-collapse" id="navbar1">
        <ul className="navbar-nav ml-auto">
          <li className="nav-item active">
            <a className="nav-link">Anasayfa</a>
          </li>
          <li className="nav-item">
            <a className="nav-link">Hakkında</a>
          </li>
          <li className="nav-item">
            <a className="nav-link">İletişim</a>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
