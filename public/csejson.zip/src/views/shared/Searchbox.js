import React, { useRef } from "react";
import { withRouter } from "react-router-dom";

const Searchbox = props => {
  const ibSearchBox = useRef(null);

  const btnSearchClick = () => {
    if (ibSearchBox.current.value === "") {
      alert("Type something...");
    } else {
      let searchText = ibSearchBox.current.value;
      props.history.push(`/search?q=${searchText}`);
    }
  };
  return (
    <div className="input-group mb-3">
      <input
        type="text"
        className="form-control"
        placeholder=""
        ref={ibSearchBox}
        onKeyDown={event => {
          if (event.key === "Enter") {
            btnSearchClick(event);
          }
        }}
      />
      <div className="input-group-append">
        <button className="btn btn-outline-success px-5" onClick={btnSearchClick}>
          Ara
        </button>
      </div>
    </div>
  );
};

export default withRouter(Searchbox);
