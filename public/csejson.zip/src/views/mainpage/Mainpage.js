import React from "react";
import Navbar from "../shared/Navbar";
import Searchbox from "../shared/Searchbox";

const Mainpage = () => {
  return (
    <>
      <div className="container-fluid p-0 h-100 w-100 d-flex flex-column">
        <Navbar />
        <div className="container h-100 w-100">
          <div className="row no-gutters justify-content-center h-100 w-100 d-flex mt-3">
            <div className="col-6 d-flex justify-content-center align-items-center">
              <Searchbox />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Mainpage;
