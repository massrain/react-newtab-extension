import React, { useEffect, useState } from "react";
import axios from "axios";
import qs from "query-string";
import Navbar from "../shared/Navbar";
import Searchbox from "../shared/Searchbox";
import * as DATA from "../../data.json";
import NProgress from "nprogress";

const Search = props => {
  const [SearchPage, setSearchPage] = useState(1);
  const [Results, setResults] = useState(null);

  useEffect(() => {
    const parsedValue = qs.parse(props.location.search).q;
    console.log(parsedValue);
    if (parsedValue === null || parsedValue === undefined || parsedValue === "") {
      alert("geçersiz arama kelimesi");
    } else {
      let key = "AIzaSyDoMZ2XnwiIeumO6-xgCcopHTVwfxVmM80";
      let cx = "partner-pub-1206609202738714:7727531761";
      let SEARCH_GET_URL = `https://www.googleapis.com/customsearch/v1?key=${key}&cx=${cx}&q=${parsedValue}&start=${SearchPage}`;
      NProgress.start();
      axios
        .get(SEARCH_GET_URL)
        .then(res => {
          console.log(res.data);
          setResults(res.data);
          NProgress.done();
        })
        .catch(err => {
          console.log(err);
          setResults(DATA.default);
          NProgress.done();
        });
    }
  }, [props.location.search, SearchPage]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [Results]);
  return (
    <>
      <div className="container-fluid p-0">
        <Navbar />
        <div className="container h-100 w-100">
          <div className="row no-gutters justify-content-center h-100 w-100 d-flex">
            <div className="col-10">
              <ResultArea setSearchPage={setSearchPage} resultData={Results} />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Search;

const ResultArea = props => (
  <>
    {console.log(props.resultData)}
    <div className="row no-gutters mt-3 justify-content-center">
      <div className="col-10">
        <Searchbox />
      </div>
    </div>
    <div className="row no-gutters justify-content-center mt-3">
      <div className="col-10">
        {props.resultData !== null
          ? props.resultData.items.map(element => <SearchResult data={element} key={element.cacheId} />)
          : null}
      </div>
    </div>
    <div className="row no-gutters justify-content-center mt-2">
      <div className="col-10">
        <ul className="pagination">
          <li className="page-item disabled">
            <button className="page-link">&laquo;</button>
          </li>
          <li className="page-item">
            <button
              className="page-link"
              onClick={() => {
                props.setSearchPage(1);
                window.scrollTo(0, 0);
              }}
            >
              1
            </button>
          </li>
          <li className="page-item">
            <button className="page-link" onClick={() => props.setSearchPage(11)}>
              2
            </button>
          </li>
          <li className="page-item">
            <button className="page-link" onClick={() => props.setSearchPage(21)}>
              3
            </button>
          </li>
          <li className="page-item">
            <button className="page-link" onClick={() => props.setSearchPage(31)}>
              4
            </button>
          </li>
          <li className="page-item">
            <button className="page-link" onClick={() => props.setSearchPage(41)}>
              5
            </button>
          </li>
          <li className="page-item">
            <button className="page-link" onClick={() => props.setSearchPage(51)}>
              6
            </button>
          </li>
          <li className="page-item">
            <button className="page-link" onClick={() => props.setSearchPage(61)}>
              7
            </button>
          </li>
          <li className="page-item">
            <button className="page-link" onClick={() => props.setSearchPage(71)}>
              8
            </button>
          </li>
          <li className="page-item">
            <button className="page-link" onClick={() => props.setSearchPage(81)}>
              9
            </button>
          </li>
          <li className="page-item disabled">
            <button className="page-link">&raquo;</button>
          </li>
        </ul>
      </div>
    </div>
  </>
);

const SearchResult = props => {
  return (
    <div className="row no-gutters my-1">
      <div className="card w-100 h-100">
        <div className="card-body p-3">
          <div className="row no-gutters">
            {props.data.pagemap.cse_thumbnail ? (
              <div className="col-1 d-flex flex-column align-items-center justify-content-center">
                <img src={props.data.pagemap.cse_thumbnail[0].src} className="img-fluid mh-80px" alt="" />
              </div>
            ) : null}

            <div className="col">
              <h5 className="card-title cursor--pointer" onClick={() => (window.location.href = props.data.link)}>
                {props.data.title}
              </h5>
              <p className="card-text">{props.data.snippet}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
