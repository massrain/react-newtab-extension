{
    "0": {
      "date": { "day": 19, "month": "Aralık", "year": "2019" },
      "image": "/assets/images/blog_1.jpg",
      "author": "Dr. John Doe",
      "topic": "Surgery",
      "title": "Lorem ipsum dolor sit amet consectetur.",
      "text":
        "Odio ultrices ut. Etiam ac erat ut enim maximus accumsan vel ac nisl. Duis feugiat bibendum orci, non elementum urna. Cras sit amet sapien aliquam, fermentum dolor non, blandit purus. Donec blandit purus vitae eros fringilla accumsan. Nunc feugiat purus et posuere ornare. Vivamus molestie sem pretium ligula efficitur, vitae auctor tortor vestibulum. Ut interdum ante neque, sed vestibulum lorem dictum quis."
    },
    "1": {
      "date": { "day": 19, "month": "Aralık", "year": "2019" },
      "image": "/assets/images/new/mevsimfoto.jpg",
      "author": "Letoon Hospital",
      "topic": "Grip",
      "title": "Mevsim değişikliğine dikkat!",
      "text": "Hava sıcaklığındaki değişimler özellikle üst ve alt solunum yolu enfeksiyonlarına neden olmakla birlikte kronik hastalıkları da tetiklemektedir.\n Basit önlemler ile bu durumladan kurtulabilirsiniz...\n Detaylı bilgi ve randevu almak için  📞 444 6 112 🚨"
    },
    "2": {
      "date": { "day": 19, "month": "Aralık", "year": "2019" },
      "image": "/assets/images/new/omuzfoto.jpg",
      "author": "Letoon Hospital",
      "topic": "Omuz Artroskopisi",
      "title": "Artroskopinin omuz eklem tedavilerindeki kullanımı",
      "text": " Omuz eklem içinin detaylı muayenesi,\n Omuz kapsülündeki sıkışmalar (Donuk Omuz Sendromu ) nedeniyle oluşan hareket kısıtlıklarının tedavisi,\n Kıkırdak hasarlarının onarımı,\n Başlangıç seviye kireçlenmelerin onarımı,\n Hasarlı eklem zarlarının onarımı,\n Kas yırtıklarının onarımı,\n Tekrar eden omuz çıkmalarının onarımı,\n Tendon yırtıklarının tamiri,\n Omuz eklem kırıklarının onarımı \n Detaylı bilgi ve randevu almak için 📞 444 6 112 🚨"
    }
}