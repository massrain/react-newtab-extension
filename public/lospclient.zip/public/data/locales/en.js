{
  "letoon_hastanesi": "Letoon Hospital",
  "navbar": {
    "sanaltur": "Virtual Tour",
    "anasayfa": "Home",
    "kurumsal": "Corporate",
    "kurumsal_anlasmalikurumlar": "Anlaşmalı Kurumlar",
    "kurumsal_hastanemiz": "Our Hospital",
    "kurumsal_kalitepolitikamiz": "Kalite Politikamız",
    "kurumsal_misyonumuz": "Our Mission",
    "kurumsal_vizyonumuz": "Our Vision",
    "kurumsal_galeri": "Gallery",
    "kurumsal_hastahaklari": "Patient rights",
    "kurumsal_hastasorumluluklari": "Patient responsibilities",
    "kurumsal_ziyaretcirehberi": "Visitors guide",
    "kurumsal_refakatcirehberi": "Refakatçi Rehberi",
    "kurumsal_halklailiskiler": "Public Relationships",
    "birimlerimiz": "Services",
    "hekimlerimiz": "Doctors",
    "iletisim": "Contact"
  },
  "footer": {
    "slogan": "First private hospital in Fethiye.",
    "slogan2": "Your health is important for us.",
    "iletisim": "Contact information",
    "konum": "Location"
  },
  "anasayfa": {
    "online_islemler": "Online Services",
    "lab_sonuc": "Laboratory Results",
    "online_randevu": "Appointment",
    "ana_duyuru1": "Hastanemizde",
    "ana_duyuru2": "Göz Estetiği",
    "ana_duyuru3": "Hizmetimiz başlamıştır",
    "newsletter_text": "Join our newsletter list.",
    "newsletter_button": "Save"
  }
}
