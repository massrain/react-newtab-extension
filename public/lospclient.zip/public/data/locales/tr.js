{
  "letoon_hastanesi": "Letoon Hastanesi",
  "navbar": {
    "sanaltur": "Sanal Tur",
    "anasayfa": "Anasayfa",
    "kurumsal": "Kurumsal",
    "kurumsal_anlasmalikurumlar": "Anlaşmalı Kurumlar",
    "kurumsal_hastanemiz": "Hastanemiz",
    "kurumsal_kalitepolitikamiz": "Kalite Politikamız",
    "kurumsal_misyonumuz": "Misyonumuz",
    "kurumsal_vizyonumuz": "Vizyonumuz",
    "kurumsal_galeri": "Galeri",
    "kurumsal_hastahaklari": "Hasta Hakları",
    "kurumsal_hastasorumluluklari": "Hasta Sorumlulukları",
    "kurumsal_ziyaretcirehberi": "Ziyaretçi Rehberi",
    "kurumsal_refakatcirehberi": "Refakatçi Rehberi",
    "kurumsal_halklailiskiler": "Halkla İlişkiler",
    "birimlerimiz": "Birimlerimiz",
    "hekimlerimiz": "Hekimlerimiz",
    "iletisim": "İletişim"
  },
  "footer": {
    "slogan": "Fethiye'nin ilk özel hastanesi.",
    "slogan2": "Sağlığınız bizim için önemlidir.",
    "iletisim": "İletişim bilgileri",
    "konum": "Konum"
  },
  "anasayfa": {
    "online_islemler": "Online İşlemler",
    "lab_sonuc": "Laboratuar Sonuç",
    "online_randevu": "Online Randevu",
    "ana_duyuru1": "Hastanemizde",
    "ana_duyuru2": "Göz Estetiği",
    "ana_duyuru3": "Hizmetimiz başlamıştır",
    "newsletter_text": "E-posta listemize katılın.",
    "newsletter_button": "Kaydet"
  }
}
