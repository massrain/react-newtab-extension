{
  "SERVICES_ICHASTALIKLARI": {
    "title": "İç Hastalıkları",
    "text": "Artık günümüzde ayrıntılı fiziki muayeneyi takiben yapılan laboratuar tetkikleri, radyolojik incelemeler, endoskopik incelemeler, EKG, Ekokardiyografi gibi modern tetkikler ile hastalıkların erken ve kesin tanısı mümkün olabilmektedir. Dahiliye bölümümüzde hastalar bir bütün olarak değerlendirildikten sonra konulan teşhis doğrultusunda gerektiğinde ilgili bölüme sevk edilir. Bu bölümümüzde üst ve alt solunum yolu hastalıkları, ateşli hastalıklar, hipertansiyon, şeker hastalığı, tiroid hastalıkları, kolesterol ve trigliserid yükseklikleri, sindirim sistemi hastalıkları, karaciğer ve safra kesesi hastalıkları, akciğer hastalıkları, böbrek hastalıkları, kansızlık ve kan hastalıkları gibi hastalıkların tanısı ve tedavisi yapılmaktadır. Hastanemizdeki dahiliye hizmetleri poliklinik muayeneleri, yatarak takip ve tedavi, ve check-up'ı içerir. Check-up kişinin herhangi bir şikayeti olmaksızın belirli periyotlarla kişinin risk faktörleri doğrultusunda yapılan geniş kapsamlı sağlık taramasıdır. Check-up'lar sayesinde birçok hayati önem taşıyan hastalıkların tanısının mümkün olan en erken dönemde konulabilmesi hastalıkların tedavi başarı olasılıklarını arttırmaktadır.",
    "doctors": ["Uz. Dr. Mehmet Behzat GÜLER", "Uz. Dr. Şenay KARADEMİR"]
  },
  "SERVICES_BEYINVESINIRCERRAHISI": {
    "title": "Beyin ve Sinir Cerrahisi",
    "text": "Beyin ve sinir cerrahisi bölümümüzde, yatan hasta hizmetlerinin yanı sıra acil klinik ve poliklinik hizmetleri de verilmektedir. Beyin tümörleri, anevrizma cerrahisi, acil bel-boyun ve omurilik travması cerrahisi, sinir cerrahisi, acil kafa travması cerrahisi, bel ve boyun fıtıklarının tedavisi hastanemizde verilen beyin cerrahisi hizmetleri arasındadır",
    "doctors": ["Op. Dr. Mustafa KORUCU"]
  },
  "SERVICES_UROLOJI": {
    "title": "Üroloji",
    "text": "Üroloji bölümümüzde kadınlarda idrar kaçırma, erkeklerde önemli bir sıkıntı olan prostat ve cinsel fonksiyon problemleri ve böbrek rahatsızlıkları gibi hastalıkların tedavileri başarıyla uygulanmaktadır. Son dönemlerde geliştirilen yeni yöntemler ile prostat konusundaki başarı oranları oldukça yükselmiştir. Hastanemizde idrar yolları taşları tedavisi de en yeni teknikler ile başarıyla uygulanmaktadır.",
    "doctors": ["Op. Dr. Jasur DJAMILOV"]
  },
  "SERVICES_ORTOPEDIVETRAVMATOLOJI": {
    "title": "Ortopedi ve Travmatoloji",
    "text": "Ortopedi ve Travmatoloji Bölümüzde ortopedik hastalıklara ilave olarak kırık, çıkık gibi travma olguları ve bunlara bağlı ortaya çıkan yapısal bozukluklara ilişkin tedavi hizmetleri verilmektedir. Hastanemizde ayrıca artroskopik diz, omuz ve ayak bileği cerrahisi, spor yaralanmaları, kalça ve diz protezleri, deformite ve kısalık, omurga hastalıkları, omuz hastalıkları, ayak hastalıkları, kas ve iskelet sistemi tümörleri, doğumsal anomaliler ve sinir kökenli kas ve kemik hastalıklarının tedavisi ve cerrahisi yapılmaktadır.",
    "doctors": ["Op. Dr. Mert KESKİNBORA", "Op. Dr. Alper ARIKAN"]
  },
  "SERVICES_GOZHASTALIKLARI": {
    "title": "Göz Hastalıkları",
    "text": "Rutin bir göz muayenesinde öncelikle, dış görünüm itibariyle göz kapakları ve gözlerin bakış pozisyonu gözlenir. Hastanın kırma kusuru ölçülür. Her iki gözün görme keskinlikleri tespit edilir. Kirpikler, konjoktiva, kornea ve gözün diğer ön segment elemanları dikkatlice muayene edilir. Ardından göz tansiyonları ölçülür. Kırma kusuru olan kişiler her yıl düzenli göz ve göz dibi muayenesinden geçmelidir. Kırma kusurlarının en önemli belirtileri görme azlığı gözlerde ağrı ve rahatsızlıktır. Kırma kusurları olan kişilere net görebilmeleri için uygun gözlük veya lens önerilir. Bazı kırma kusurları ise lazer tedavisiyle ile düzelebilir. Göz muayenesi ile ayrıca hipertansiyon, beyin tümörü gibi vücuttaki bazıhastalıklara ait belirtiler de saptanabilir. Hastanemizde katarakt ameliyatları başarıyla yapılmaktadır. Yüksek oranda yaşa bağlı ortaya çıkan katarakt gözün içinde bulunan doğal merceğin saydamlığını kaybetmesidir. Ağrısız görme kaybı, kamaşma veya ışığa duyarlılığın artması, renklerde soluklaşma ve sararma, gece görüşün bozulması kataraktın sık rastlanan belirtilerindendir. Kataraktın tek tedavisi ameliyattır. Ani körlüğe neden olabilen glokom (göz tansiyonu yükselmesi) rahatsızlığının görme bulanıklığı, şiddetli göz ağrısı, baş ağrısı, bulantı, kusma ve hareli görme gibi bulguları vardır. Düzenli olarak yapılan göz muayenesi bu hastalığın saptanması için en etkili yöntemdir. Glokom nedeniyle gözde gerçekleşen görme kaybı geri döndürülemez. Damla tedavisi, lazer cerrahisi ve cerrahi müdahaleler daha ileri kayıpların meydana gelmesini engellemek için uygulanır. Hastanemizde ayrıca şaşılık tedavisi de yapılmaktadır. Şaşılık tedavisinde amaç görmenin arttırması baş pozisyonunun çift görmenin düzeltilmesi, göz hareketlerinin sağlanması ve estetik yakınmaların giderilmesidir. Şaşılık cerrahi yöntemlerle tedavi edilir.",
    "doctors": ["Op. Dr. Hasan TEKİN"]
  },
  "SERVICES_COCUKHASTALIKLARI": {
    "title": "Çocuk Hastalıkları",
    "text": "Polikliniğimizde hem sağlıklı çocukların rutin kontrolleri yapılmakta, aşıları takip edilmekte hem de hasta çocukların teşhis ve tedavisi yapılmaktadır. Hastanemizde ayrıca yeni doğan bebeklerimiz bebek gözlem odasında bulunan deneyimli hemşirelerimiz gözetiminde takip edilmekte ve uzman çocuk doktorları kontrolünde tüm rutin kontrolleri ve tetkikleri yapıldıktan sonra taburcu olmaktadır. Ayrıca erken doğum veya problemli doğumlarda bebeklerin tedavileri Yeni Doğan Yoğun Bakım ünitemizde en iyi şekilde yapılmaktadır.",
    "doctors": ["Uz. Dr. İhsan BÜYÜKÇALIK", "Uz. Dr. Yasemin ONURSAL HELVACI", "Uz. Dr. Hüseyin HELVACI"]
  },
  "SERVICES_KULAKBURUNBOGAZ": { "title": "Kulak Burun Boğaz", "text": "", "doctors": ["Op. Dr. Alev GÜNAL"] },
  "SERVICES_DIS": {
    "title": "Diş",
    "text": "Hastanemizin ağız ve diş sağlığı bölümü, koruyucu dişhekimliği, pedodonti (çocuk dişleri), ortodonti (çapraşık dişler), endodonti (kanal tedavisi), konservatif tedavi, protez, periodontoloji (dişeti hastalıkları) ve ağız cerrahisi gibi genel dişhekimliği uygulamalarına ilaveten, lazer dişhekimliği, estetik dişhekimliği, implantoloji ve çene cerrahisi gibi özel konularda da hizmet vermektedir.",
    "doctors": ["Bu birimde görevli hekim bulunmamaktadır."]
  },
  "SERVICES_GENELCERRAHI": {
    "title": "Genel Cerrahi",
    "text": "Hastanemizin genel cerrahi bölümünde gerekli deneyim ve beceriye sahip cerrah kadrosu ile meme, endokrin, karaciğer, pankreas, safra yolları, kolon rektum cerrahisi ve laparoskopik cerrahi gibi konularda pek çok sayıda ameliyat başarıyla gerçekleştirilmektedir.",
    "doctors": ["Op. Dr. Servet EMEKSİZ"]
  },
  "SERVICES_ANASTEZIVEREANIMASYON": {
    "title": "Anestezi ve Reanimasyon",
    "text": "Hastanemizde ameliyat edilen hastalar, uygulanan başarılı anestezi teknikleri ve deneyimli ekip sayesinde ameliyat sonrası ağrısız, şikayetsiz ve sorunsuz bir şekilde taburcu edilmektedir. Anestezi doktorlarımız ameliyat süresince hastanın tüm yaşamsal fonksiyonlarını takip ederek, gerektiğinde müdahalelerde bulunmaktadır. Ameliyat öncesinde hastalar anestezi doktoru tarafından değerlendirilir. Anestezi muayenesinden sonra hastanın genel durumu doğrultusunda gerekli tetkikleri yapılır. Sonuçlar değerlendirildikten sonra hasta anesteziye hazırlanır. En uygun anestezi tekniği belirlendikten sonra yapılan anestezi uygulaması ile ameliyatlar gerçekleştirilir. Böylece ameliyat riski en aza indirilir.",
    "doctors": ["Uz. Dr. Mehmet B. DEMİR", "Uz. Dr. Osman Nuri BÜYÜKER"]
  },
  "SERVICES_KADINDOGUM": {
    "title": "Kadın Doğum",
    "text": "Hastanemizin kadın hastalıkları ve doğum bölümünde doğumların yanı sıra pek çok jinekolojik operasyon başarıyla uygulanmaktadır. Hastanemizde ayrıca bu alanda hastalık ortaya çıkmadan engellenmesi için koruyucu hekimlik uygulamaları yapılmaktadır. Kadın hastalıkları ve doğum bölümümüzde smear, HPV tiplemesi, HPV aşısı, anormal smearin yönetimi ve takibi, kryoterapi, kolposkopi, myom ve kist operasyonları ve histeroskopi gibi bütün geleneksel ve modern tedaviler uygulanmaktadır. Bu tedavilerin yanı sıra normal ve riskli gebelik takibi ve doğumu konularında hizmet verilmektedir.",
    "doctors": ["Op. Dr. Ahmet GÜLDAŞ"]
  },
  "SERVICES_ACILSERVIS": {
    "title": "Acil Servis",
    "text": "Hastanemizin acil servis bölümü haftada 7 gün 24 saat acil sağlık hizmeti vermektedir. Acil servisimiz yabancı dil bilen acil hekimlerimiz ile yabancı hastaların taleplerine en iyi şekilde cevap verebilmektedir. Gerektiğinde, iç hastalıkları, ortopedi, kardiyoloji, radyoloji, nöroloji, üroloji, KBB, göz hastalıkları, çocuk cerrahisi uzmanları da her türlü acil duruma hazırlıklı olarak hızla hastaneye ulaşır. Acil servise başvuran hastalar aciliyetine ve hastalığına göre uygun odaya alınır ve acil servis hekimi tarafından muayene edilir. Mümkün olan en kısa süre içinde tamamlanan tetkik ve değerlendirmelerin sonucunda, acil servis uzmanımız, gerekiyorsa hastadan ileri tetkik veya branş hekiminden konsültasyon isteyebilir.",
    "doctors": [
      "Dr. Tareq M.A A. RYALAT",
      "Dr. Sadam K. Al Smadi",
      "Dr. İsa ÇELİK",
      "Dr. Alide MAMBETOVA",
      "Dr. Cem BOZTOSUN"
    ]
  },
  "SERVICES_YABANCIHASTALIKLAR": {
    "title": "",
    "text": "",
    "doctors": ["Bu birimde görevli hekim bulunmamaktadır."]
  },
  "SERVICES_RADYOLOJI": {
    "title": "Radyoloji",
    "text": "",
    "doctors": ["Uz. Dr. Mehmet MUNDUZ", "Uz. Dr. Nail KOÇER"]
  },
  "SERVICES_BIYOKIMYA": {
    "title": "Biyokimya",
    "text": "",
    "doctors": ["Uz. Dr. Nevin ARICAN"]
  },
  "SERVICES_COCUKCERRAHISI": {
    "title": "Çocuk Cerrahisi",
    "text": "Hastanemizde her çeşit çocuk cerrahisi ameliyatı yapılabilmektedir. Kasık fıtığı, inmemiş testis, apandisit gibi sık karşılaşılan ameliyatlar yanında, boyunda ve vücutta gerek sonradan gelişmiş, gerekse de doğuştan gelen her türlü rahatsızlık cerrahi olarak tedavi edilebilmektedir.",
    "doctors": ["Op. Dr. Osman Nuri BÜYÜKER"]
  },
  "SERVICES_FTR": {
    "title": "F. T. R.",
    "text": "",
    "doctors": ["Uz. Dr. Gül TÜRKMEN"]
  },
  "SERVICES_KARDIYOLOJI": {
    "title": "Kardiyoloji",
    "text": "Kalp hastalıklarının görülme yaşı her geçen gün düştüğünden kalp hastalıklarından korunma, çocuk yaşta başlayan kontrollerle daha başarılı olmaktadır. Hastanemizin kardiyoloji bölümü’nde doğuştan veya sonradan başlayan kalp hastalıklarının tanı ve tedavisi yapılmaktadır. Kardiyoloji bölümümüz bünyesinde kardiyoloji polikliniği hizmetinin yanısıra EKG, efor testi, ekokardiyografi gibi tetkikler yapılmaktadır.",
    "doctors": ["Uz. Dr. Ufuk Ali TÜRK"]
  },
  "SERVICES_BESLENMEVEDIYET": {
    "title": "Beslenme ve Diyet",
    "text": "",
    "doctors": ["Dyt. Şule ŞAHİN"]
  },
  "SERVICES_GOGUSHASTALIKLARI": {
    "title": "Göğüs Hastalıkları",
    "text": "",
    "doctors": ["Uz. Dr. Mehmet Coşkun ÖZER"]
  }
}
