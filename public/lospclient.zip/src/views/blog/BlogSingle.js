import React from "react";
import { BLOG } from "../../helpers/routes";
import { useHistory } from "react-router-dom";

const BlogSingle = props => {
  let history = useHistory();

  const colorblue = {
    color: "#57ccc3",
    fontSize: "14px",
    fontWeight: 600
  };
  const blogtitle = {
    fontSize: "30px",
    fontWeight: 600,
    color: "#404040",
    lineHeight: 1.2
  };

  const pushToBlog = () => {
    history.push(BLOG);
  };
  return (
    <>
      <div className="blog_post border border-muted p-2 rounded-lg" style={{ marginBottom: "25px" }}>
        <div className="blog_post_image">
          <img src={props.data.image} style={{maxHeight: "40vh"}} alt="" className="img-fluid rounded-lg" />
        </div>
        <div className="blog_post_date d-flex flex-column align-items-center justify-content-center">
          <div className="date_day">{props.data.date.day}</div>
          <div className="date_month">{props.data.date.month}</div>
          <div className="date_year">{props.data.date.year}</div>
        </div>
        <div className="blog_post_title" style={{ marginTop: "25px" }}>
          <span style={blogtitle}>{props.data.title}</span>
        </div>
        <div className="blog_post_info">
          <ul className="d-flex flex-row align-items-center justify-content-center">
            <li>
              <span style={colorblue}>{props.data.author}</span> tarafından
            </li>
            <li>
              <span style={colorblue}>{props.data.topic}</span> hakkında
            </li>
          </ul>
        </div>
        <div className="blog_post_text text-center" style={{ marginTop: "5px" }}>
          <p style={{ whiteSpace: "pre-line" }}>{props.data.text}</p>
          <small className="text-info" style={{ cursor: "pointer" }} onClick={pushToBlog}>
            Detay...
          </small>
        </div>
      </div>
    </>
  );
};

export default BlogSingle;
