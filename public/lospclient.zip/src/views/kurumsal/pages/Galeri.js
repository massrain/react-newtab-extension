import React from "react";
import Sidebar from "./Sidebar";

const Galeri = () => {
  let resim1 = "http://www.letoonhospital.com.tr/images/galeri/kucuk/1.jpg";
  let link1 = "http://www.letoonhospital.com.tr/images/galeri/1.jpg";
  let resim2 = "http://www.letoonhospital.com.tr/images/galeri/kucuk/2.jpg";
  let link2 = "http://www.letoonhospital.com.tr/images/galeri/2.jpg";
  let resim3 = "http://www.letoonhospital.com.tr/images/galeri/kucuk/3.jpg";
  let link3 = "http://www.letoonhospital.com.tr/images/galeri/3.jpg";

  return (
    <>
      <div className="services mt-5">
        <div className="container">
          <div className="row">
            <div className="col-9">
              <div className="row">
                <div className="col text-center">
                  <div className="section_title_container text-left">
                    <div className="section_title">
                      <h2>Galeri</h2>
                    </div>
                    <div className="row no-gutters my-3">
                      <div className="col-4">
                        <a href={link1}>
                          <img src={resim1} alt="" className="img-fluid" />
                        </a>
                      </div>
                      <div className="col-4">
                        <a href={link2}>
                          <img src={resim2} alt="" className="img-fluid" />
                        </a>
                      </div>
                      <div className="col-4">
                        <a href={link3}>
                          <img src={resim3} alt="" className="img-fluid" />
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-3">
              <div className="row services_row">
                <Sidebar />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Galeri;
