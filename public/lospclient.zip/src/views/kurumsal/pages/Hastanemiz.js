import React from "react";
import Sidebar from "./Sidebar";

const Hastanemiz = () => {
  return (
    <>
      <div className="services mt-5">
        <div className="container">
          <div className="row">
            <div className="col-9">
              <div className="row">
                <div className="col text-center">
                  <div className="section_title_container text-left">
                    <div className="section_title">
                      <h2>Hastanemiz</h2>
                    </div>
                    <p>
                      Fethiye'nin ilk özel hastanesi olan Özel Letoon Hospital, 1997 yılında şu anki mevcut adresi olan Pazaryeri Mahallesi
                      Süleyman Demirel Bulvarı Şehit Hasan Küçükçoban Caddesi No: 22 Fethiye adresinde faaliyet vermeye başladı.
                    </p>
                    <p>
                      Hizmet binamız 3+1 kattan oluşmakta olup; hastanemizin zemin katında Göğüs Hastalıkları, Kadın Hastalıkları ve Doğum,
                      Çocuk Sağlığı ve Hastalıkları ile Radyoloji Poliklinikleri; MR Merkezi, Tomografi, Biyokimya Laboratuvarı, Odyometri,
                      Morg, Kemik Ölçümü, Doğumhane, Ameliyathaneler, Yeni Doğan Yoğun Bakım Ünitesi ve Hasta Yatış ve Taburculuk Birimi ile
                      Santral;
                    </p>
                    <p>
                      Giriş Katında; Güvenlik, Hasta Kabul ve Yönlendirme, Hasta Danışma, Hasta Hakları ve İletişim Birimi, Başhekimlik,
                      Kadın Hastalıkları ve Doğum, İç Hastalıkları, Üroloji, Beyin Cerrahisi, Kulak Burun Boğaz, Göz Sağlığı ve
                      Hastalıkları, Çocuk Sağlığı ve Hastalıkları, Ortopedi ve Travmatoloji, Genel Cerrahi, Cilt ve Zühravi Hastalıklar
                      Poliklinikleri, Röntgen ve Turizm Ofisi ile Acil Servis ve Gözlem Odaları;
                    </p>
                    <p>1. Katta Cerrahi ve Dahili Yoğun Bakım, Koroner Yoğun Bakım Ünitesi ve Servisler;</p>
                    <p>
                      2. Katta Kadın Doğum Servisi, Eczane, Kardiyoloji ve İç Hastalıkları, Ortopedi ve Travmatoloji, Fizik Tedavi
                      Poliklinikleri, Ekokardiyografi ve Eforlu EKG;
                    </p>
                    <p>3. Katta ise Yemekhane, Tıbbi Arşiv, Toplantı Salonu ve Mutfak mevcuttur.</p>
                    <p>
                      Hastanemizin Acil ve Ambulans Hizmetleri 7 Gün 24 Saat hizmet vermektedir. Polikliniklerimiz sabah saat 08:00'da hasta
                      kabulüne başlar ve kış döneminde 17:30; yaz döneminde 18:00' a kadar hizmet verir. Bununda dışında Çocuk Sağlığı ve
                      Hastalıkları Polikliniklerimiz her hafta bir hekimimiz olacak şekilde dönüşümlü olarak saat 23:00' a kadar hasta
                      kabulü yapmaktadır.
                    </p>
                    <p>Hastanemizde 2 tanesi Acil Yardım ve 1 tanesi Hasta Nakil olmak üzere toplam 3 adet ambulansımız mevcuttur.</p>
                    <p>
                      Hastanemizde kullanılmakta olan PAKS Sistemi sayesinde hastalarımıza ait radyoloji görüntüleri CD olarak kendileriyle
                      paylaşılmaktadır. Ayrıca İnternet Sitemiz üzerinden 7 gün 24 saat boyunca online olarak randevu alınabilmekte ve
                      laboratuvar sonuçlarına ulaşılabilmektedir.
                    </p>
                    <hr />
                    <h5> Sağlığınız bizim için önemlidir.</h5>
                    <p />
                  </div>
                </div>
              </div>
            </div>
            <div className="col-3">
              <div className="row services_row">
                <Sidebar />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Hastanemiz;
