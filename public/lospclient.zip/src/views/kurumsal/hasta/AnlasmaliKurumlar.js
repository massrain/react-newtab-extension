import React, { useState, useEffect } from "react";
import Sidebar from "../pages/Sidebar";

const AnlasmaliKurumlar = () => {
  const [AKurumlar, setAKurumlar] = useState([]);

  function json2array(json) {
    var result = [];
    var keys = Object.keys(json);
    keys.forEach(function(key) {
      result.push(json[key]);
    });
    return result;
  }

  useEffect(() => {
    fetch("/data/anlasmalikurumlar.js")
      .then(response => {
        return response.json();
      })
      .then(data => {
        setAKurumlar(json2array(data));
      });
  }, []);

  return (
    <>
      <div className="services mt-5">
        <div className="container">
          <div className="row">
            <div className="col-9">
              <div className="row">
                <div className="col text-center">
                  <div className="section_title_container text-left">
                    <div className="section_title text-center">
                      <h2>Anlaşmalı Kurumlar</h2>
                    </div>
                    <div className="row no-gutters my-3">
                      {AKurumlar.map((element, i) => (
                        <SingleAnlasmaliKurum data={element} dataindex={i} key={i} />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-3">
              <div className="row services_row">
                <Sidebar />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AnlasmaliKurumlar;

const SingleAnlasmaliKurum = props => (
  <div className="col-4 text-center p-2 border border-muted">
    <img src={props.data.img} alt={props.data.name} />
    <p>{props.data.name}</p>
  </div>
);
