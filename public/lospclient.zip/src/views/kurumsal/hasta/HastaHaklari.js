import React from "react";
import Sidebar from "../pages/Sidebar";

const HastaHaklari = () => {
  return (
    <>
      <div className="services mt-5">
        <div className="container">
          <div className="row">
            <div className="col-9">
              <div className="row">
                <div className="col text-center">
                  <div className="section_title_container text-left">
                    <div className="section_title">
                      <h2>Hasta Hakları</h2>
                    </div>
                    <h5>Hastanemize başvuran tüm hastalarımızın;</h5>
                    <p className="font-weight-bold">Hizmetten genel olarak faydalanma</p>
                    <p>
                      Adalet ve hakkaniyet ilkeleri çerçevesinde sağlıklı yaşamanın teşvik edilmesine yönelik faaliyetler ve koruyucu sağlık
                      hizmetlerinden faydalanmaya,
                    </p>
                    <p className="font-weight-bold">Eşitlik içinde hizmete ulaşma</p>
                    <p>
                      Irk, dil, din ve mezhep, cinsiyet, siyasi düşünce, felsefi inanç, ekonomik ve sosyal durumları dikkate alınmadan
                      hizmet almaya,
                    </p>
                    <p className="font-weight-bold">Bilgilendirilme</p>
                    <p>Her türlü hizmet ve imkanın neler olduğunu öğrenmeye,</p>
                    <p className="font-weight-bold">Kuruluşu seçme ve değiştirme</p>
                    <p>Sağlık kuruluşunu seçme ve değiştirmeye ve seçtiği sağlık kuruluşunda verilen sağlık hizmetlerinden faydalanmaya,</p>
                    <p className="font-weight-bold">Personeli tanıma, seçme ve değiştirme</p>
                    <p>
                      Sağlık hizmeti verecek ve vermekte olan tabiplerin ve diğer personelin kimliklerini, görev ve ünvanlarını öğrenmeye,
                      seçme ve değiştirmeye,
                    </p>
                    <p className="font-weight-bold">Bilgi İsteme</p>
                    <p>Sağlık durumu ile ilgili her türlü bilgiyi sözlü veya yazılı olarak istemeye,</p>
                    <p className="font-weight-bold">Mahremiyet</p>
                    <p>Gizliliğe uygun olan bir ortamda her türlü sağlık hizmetini almaya,</p>
                    <p className="font-weight-bold">Rıza ve İzin</p>
                    <p>Tıbbi müdahalelerde rızanın alınmasına ve rıza çerçevesinde hizmetten faydalanmaya,</p>
                    <p className="font-weight-bold">Reddetme ve durdurma</p>
                    <p>Tedaviyi reddetmeye ve durdurulmasını istemeye,</p>
                    <p className="font-weight-bold">Güvenlik</p>
                    <p>Sağlık hizmetini güvenli bir ortamda almaya,</p>
                    <p className="font-weight-bold">Dini vecibelerini yerine getirebilme</p>
                    <p>Kuruluşun imkanları ölçüsünde ve idarece alınan tedbirler çerçevesinde, dini vecibelerini yerine getirmeye,</p>
                    <p className="font-weight-bold">Saygınlık görme</p>
                    <p>Saygı, itina ve ihtimam gösterilerek, güleryüzlü, nazik, şefkatli sağlık hizmeti almaya,</p>
                    <p className="font-weight-bold">Rahatlık</p>
                    <p>
                      Her türlü hijyenik şartlar sağlanmış, gürültülü ve rahatsız edici bütün etkenler giderilmiş bir ortamda sağlık hizmeti
                      almaya,
                    </p>
                    <p className="font-weight-bold">Ziyaret</p>
                    <p>Kurum ve kuruluşlarca belirlenen usül ve esaslara uygun olarak ziyaretçi kabul etmeye,</p>
                    <p className="font-weight-bold">Refakatçi bulundurma</p>
                    <p>
                      Mevzuatın, sağlık kurum ve kuruluşlarının imkanları ölçüsünde ve tabibin uygun görmesi durumunda refakatçi
                      bulundurmayı istemeye,
                    </p>
                    <p className="font-weight-bold">Müracaat, şikayet ve dava hakkı</p>
                    <p>Haklarının ihlali halinde, mevzuat çerçevesinde her türle başvuru, şikayet ve dava hakkını kullanmaya,</p>
                    <p className="font-weight-bold">Sürekli hizmet</p>
                    <p>Gerektiği sürece. sağlık hizmetlerinden yararlanmaya,</p>
                    <hr />
                    <h5>HAKKI VARDIR.</h5>
                    <p />
                  </div>
                </div>
              </div>
            </div>
            <div className="col-3">
              <div className="row services_row">
                <Sidebar />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default HastaHaklari;
