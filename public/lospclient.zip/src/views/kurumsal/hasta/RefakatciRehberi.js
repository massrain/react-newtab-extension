import React from "react";
import Sidebar from "../pages/Sidebar";

const RefakatciRehberi = () => {
  return (
    <>
      <div className="services mt-5">
        <div className="container">
          <div className="row">
            <div className="col-9">
              <div className="row">
                <div className="col text-center">
                  <div className="section_title_container text-left">
                    <div className="section_title">
                      <h2>Refakatçı Rehberi</h2>
                    </div>
                    <p className="font-weight-bold">
                      Hastanemizde konaklayan misafirlerimizden özellikle kendi kendilerini idare edemeyecek durumda olanların ve tümünün
                      refakatçı hakkı bulunmaktadır;
                    </p>
                    <p>
                      Refakat süresince hasta sağlığı ve rafahı açısından sizin için hazırlamış olduğumuz bu rehbere uyum sağlamanızı önemle
                      rica ediyoruz.
                    </p>
                    <p className="font-weight-bold">Bu konuda anlayışınız için teşekkür ederiz.</p>
                    <hr />
                    <p>- Hastanemize ait olan eşyaları düzenli kullanınız,</p>
                    <p>- Koridorlarda ve hasta odalarında yüksek sesle konuşmayınız,</p>
                    <p>- Bir başkasının refakat edecek olması durumunda lütfen servis hemşiresini bilgilendiriniz,</p>
                    <p>- Hasta sağlığı açısından odada kalabalık olmaması konusunda çalışanlarımıza destek olunuz,</p>
                    <p>- Refakat süresince lütfen hasta odasında sigara içmeyiniz,</p>
                    <p>
                      - Hemşire çağırmak için oda tanıtımında size tarif edildiği şekilde hemşire çağrı zilini ya da telefonu kullanınız,
                    </p>
                    <p>- Hastanızın genel durumundaki değişikliklerden çalışanlarımızı bilgilendiriniz,</p>
                    <p>- Hastanızın beslenmesini hekimin tarif ettiği şekilde sağlanmasına dikkat ediniz,</p>
                    <p>- Hekim ya da hemşire bilgisi dışında kendi isteğinize göre hastaya yiyecek vermeyiniz,</p>
                    <p>- Hekimin ya da hemşirenin bilgisi olmadan odasını ya da yatağını değiştirmeyiniz,</p>
                    <p>
                      - Serum ya da ilaç uygulamaları konusunda kendi başınıza hareket etmeyiniz ve hastanızın yanında kendisine ait ilaç
                      bulunuyorsa bunu mutlaka servis hemşiresine bildiriniz.
                    </p>
                    <p className="font-weight-bold">Hastane refakatçı kurallarına uyduğunuz için teşekkür ederiz.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-3">
              <div className="row services_row">
                <Sidebar />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default RefakatciRehberi;
