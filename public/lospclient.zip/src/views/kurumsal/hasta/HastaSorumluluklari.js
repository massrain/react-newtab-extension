import React from "react";
import Sidebar from "../pages/Sidebar";

const HastaSorumluluklari = () => {
  return (
    <>
      <div className="services mt-5">
        <div className="container">
          <div className="row">
            <div className="col-9">
              <div className="row">
                <div className="col text-center">
                  <div className="section_title_container text-left">
                    <div className="section_title">
                      <h2>Hasta Sorumlulukları</h2>
                    </div>
                    <p>
                      Son dönemde hasta haklarının yanında bir de “ Hasta Sorumluluğu” kavramı ortaya çıkmıştır. Henüz bu kavramın, içeriği
                      ve kapsamı ortaya konmamıştır. Ancak genel olarak, hastanın bir sağlık kuruluşuna başvurmadan ve başvurduktan sonraki
                      süreçte yerine getirmesi gereken ödev ve yükümlülüklerdir diye tarif edilebilir. Hastanın sorumluluklarını
                      boyutlandırmamız mümkündür. Kısaca maddeler halinde sıralayabiliriz:
                    </p>
                    <p className="font-weight-bold">Genel Sorumluluklar</p>
                    <p>
                      Kişiler kendi sağlığına dikkat etmek için elinden geleni yapmalı ve sağlıklı bir yaşam için verilen tavsiyelere
                      uymalıdır. Kişi uygunsa kan verebilir ya da organ bağışında bulunabilir. Basit durumlarda kişiler kendi bakımlarını
                      yapmalıdır.
                    </p>
                    <p className="font-weight-bold">Sosyal Güvenlik Durumu</p>
                    <p>
                      Hasta; sağlık, sosyal güvenlik ve kişisel bilgilerindeki değişiklikleri zamanında bildirmek durumundadır. Hasta;
                      sağlık karnesinin (Bağ-Kur, Yeşil Kart gibi) vizesini zamanında yaptırmak zorundadır.
                    </p>
                    <p className="font-weight-bold">Sağlık Çalışanlarını Bilgilendirme</p>
                    <p>
                      Hasta; yakınmalarını, daha önce geçirdiği hastalıkları, yatarak herhangi bir tedavi görüp görmediğini, eğer varsa
                      halen kullandığı ilaçları ve tüm sağlığıyla ilgili bilgileri tam, eksiksiz vermelidir.
                    </p>
                    <p className="font-weight-bold">Hastane Kurallarına Uyma</p>
                    <p>
                      Hasta; başvurduğu sağlık kuruluşunun kural ve uygulamalarına uymalıdır. Hasta sağlık Bakanlığı ve diğer sosyal
                      güvenlik kurumlarınca belirlenen sevk zincirine uymalıdır. Hastanın; tedavi, bakım ve rehabilitasyon sürecince sağlık
                      çalışanları ile işbirliği içinde olması beklenir. Hasta; randevulu hizmet veren bir sağlık tesisinden yararlanıyorsa
                      randevunun tarih ve saatine uyması ve değişiklikleri ilgili yere bildirmesi gerekir. Hasta; hastane personelinin,
                      diğer hastaların ve ziyaretçilerin haklarına saygı göstermelidir. Hasta; hastane malzemelerine verdiği zararları
                      karşılamak zorundadır.
                    </p>
                    <p className="font-weight-bold">Tedavisi İle İlgili Önerilere Uyma</p>
                    <p>
                      Hasta; tedavisi ve ilaçlarla ilgili tavsiyeleri dikkatle dinlemeli ve anlayamadığı yerleri sormalıdır. Hastanın;
                      tedavisiyle ilgili önerilere uyum sağlayamama durumu söz konusu ise bunu sağlık çalışanına bildirmesi gerekir. Hasta
                      sağlık bakım ve taburculuk sonrası bakım planını beklendiği gibi doğru anlayıp anlamadığını belirtmesi gerekir. Hasta;
                      uygulanacak tedaviyi reddetmesi veya önerilere uymamasından dolayı doğacak sonuçlardan kendisi sorumludur.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-3">
              <div className="row services_row">
                <Sidebar />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default HastaSorumluluklari;
