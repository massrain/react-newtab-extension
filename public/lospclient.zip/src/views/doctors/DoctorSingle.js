import React from "react";
import { useHistory } from "react-router-dom";
import { DOCTORS_DETAIL } from "../../helpers/routes";

const DoctorSingle = props => {
  const history = useHistory();
  const linkStyle = {
    fontSize: "24px",
    fontWeight: "600",
    color: "#404040",
    cursor: "pointer"
  };
  const returnDocDetail = () => {
    history.push(DOCTORS_DETAIL + "/" + props.dataindex);
  };
  return (
    <>
      <div className="col-lg-4 team_col">
        <div className="team_item text-center d-flex flex-column aling-items-center justify-content-end">
          <div className="team_image">
            <img src={props.data.img} alt="" />
          </div>
          <div className="team_content text-center">
            <div className="team_name">
              <span style={linkStyle} onClick={returnDocDetail}>
                {props.data.name}
              </span>
            </div>
            <div className="team_title">{props.data.birim}</div>
            <div className="team_text">
              <p>{props.data.unvan}</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default DoctorSingle;
