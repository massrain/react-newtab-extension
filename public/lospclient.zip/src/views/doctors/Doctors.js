import React, { useState, useEffect } from "react";
import "../../styles/about.css";
import "../../styles/about_responsive.css";
import DoctorSingle from "./DoctorSingle";

const Doctors = () => {
  const [Doctors, setDoctors] = useState([]);

  function json2array(json) {
    var result = [];
    var keys = Object.keys(json);
    keys.forEach(function(key) {
      result.push(json[key]);
    });
    return result;
  }

  useEffect(() => {
    fetch("/data/doctors.js")
      .then(response => {
        return response.json();
      })
      .then(data => {
        setDoctors(json2array(data));
      });
  }, []);

  useEffect(() => {
    const script2 = document.createElement("script");
    script2.src = "/assets/plugins/parallax-js-master/parallax.min.js";
    script2.async = true;
    document.body.appendChild(script2);

    return () => {
      document.body.removeChild(script2);
    };
  }, []);

  return (
    <>
      {/* Home */}
      <div className="home d-flex flex-column align-items-start justify-content-end">
        {/* <div class="background_image" style="background-image:url(images/about.jpg)"></div> */}
        <div
          className="parallax_background parallax-window"
          data-parallax="scroll"
          data-image-src="/assets/images/about.jpg"
          data-speed="0.8"
        />
        <div className="home_overlay">
          <img src="/assets/images/home_overlay.png" alt="" />
        </div>
        <div className="home_container">
          <div className="container">
            <div className="row">
              <div className="col">
                <div className="home_content">
                  <div className="home_title">Hekimlerimiz</div>
                  <div className="home_text">Hastanemiz bünyesindeki, alanında uzman kadromuz</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Team */}
      <div className="team" style={{ paddingTop: "15px" }}>
        <div className="container">
          <div className="row team_row">
            {/* Team Item */}
            {Doctors.map((element, i) => (
              <DoctorSingle data={element} dataindex={i} key={i} />
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default Doctors;
