import React from "react";
import { Link } from "react-router-dom";
import { HOME } from "../../helpers/routes";
import { useTranslation } from "react-i18next";

const Footer = () => {
  const { t } = useTranslation();
  return (
    <>
      {/* Footer */}
      <footer className="footer">
        <div className="footer_content" style={{ paddingTop: "50px" }}>
          <div className="container">
            <div className="row">
              <div className="col-12 text-center">
                <a href="http://www.kanver.org" target="_blank" rel="noopener noreferrer">
                  <img alt="Kan" className="img-fluid" height={90} width={728} src="/assets/images/new/kanver.gif" />
                </a>
              </div>
            </div>
            <div className="row">
              {/* Footer About */}
              <div className="col-lg-4 footer_col">
                <div className="footer_about">
                  <div className="footer_logo">
                    <Link to={HOME}>
                      <img src="/assets/images/letoonlogo.png" alt="" className="img-fluid" />
                    </Link>
                  </div>
                  <div className="footer_about_text">
                    <p>{t("footer.slogan")}</p>
                    <p>{t("footer.slogan2")}</p>
                  </div>
                </div>
              </div>
              {/* Footer Contact Info */}
              <div className="col-lg-4 footer_col">
                <div className="footer_contact">
                  <div className="footer_title">{t("footer.iletisim")}</div>
                  <ul className="contact_list">
                    <li>444 6 112</li>
                    <li>info@letoonhospital.com.tr</li>
                    <li>www.letoonhospital.com.tr</li>
                  </ul>
                </div>
              </div>
              {/* Footer Locations */}
              <div className="col-lg-4 footer_col">
                <div className="footer_location">
                  <div className="footer_title">{t("footer.konum")}</div>
                  <ul className="locations_list">
                    <li>
                      <div className="location_title">Fethiye/ MUĞLA</div>
                      <div className="location_text">Pazaryeri Mahallesi Şehit Hasan Küçükçoban Cad. No: 22 48300</div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
};

export default Footer;
