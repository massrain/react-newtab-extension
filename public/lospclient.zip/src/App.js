import React from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Navbar from "./views/shared/Navbar";
import Home from "./views/home/Home";
import Contact from "./views/contact/Contact";
import Doctors from "./views/doctors/Doctors";
import Blog from "./views/blog/Blog";
import Footer from "./views/shared/Footer";
import { HOME, CONTACT, DOCTORS, BLOG, SERVICES, KURUMSAL, DOCTORS_DETAIL } from "./helpers/routes";
import Services from "./views/services/Services";
import Kurumsal from "./views/kurumsal/Kurumsal";
import ScrollToTop from "./ScrollToTop";
import DoctorsDetail from "./views/doctors/DoctorsDetail";

function App() {
  return (
    <>
      <Router>
        <ScrollToTop>
          <Navbar />
          <Switch>
            <Route exact path={HOME}>
              <Home />
            </Route>
            <Route exact path={CONTACT}>
              <Contact />
            </Route>
            <Route exact path={DOCTORS}>
              <Doctors />
            </Route>
            <Route exact path={DOCTORS_DETAIL + "/:id"}>
              <DoctorsDetail />
            </Route>
            <Route exact path={BLOG}>
              <Blog />
            </Route>
            <Route path={SERVICES}>
              <Services />
            </Route>
            <Route path={KURUMSAL}>
              <Kurumsal />
            </Route>
            <Route component={NotFound} />
          </Switch>
          <Footer />
        </ScrollToTop>
      </Router>
    </>
  );
}

export default App;

const NotFound = () => (
  <>
    <div className="services mt-5">
      <div className="container">
        <div className="row no-gutters">
          <div className="col-9 text-center">
            <div className="text-danger font-weight-bold">404 not found</div>
          </div>
        </div>
      </div>
    </div>
  </>
);
