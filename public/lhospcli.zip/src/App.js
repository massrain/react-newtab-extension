import React from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Navbar from "./views/shared/Navbar";
import Home from "./views/home/Home";
import Contact from "./views/contact/Contact";
import Doctors from "./views/doctors/Doctors";
import Blog from "./views/blog/Blog";
import Footer from "./views/shared/Footer";
import { HOME, CONTACT, DOCTORS, BLOG, SERVICES, KURUMSAL } from "./helpers/routes";
import Services from "./views/services/Services";
import Kurumsal from "./views/kurumsal/Kurumsal";
import ScrollToTop from "./ScrollToTop";

function App() {
  return (
    <>
      <Router>
        <ScrollToTop>
          <Navbar />
          <Switch>
            <Route exact path={HOME}>
              <Home />
            </Route>
            <Route exact path={CONTACT}>
              <Contact />
            </Route>
            <Route exact path={DOCTORS}>
              <Doctors />
            </Route>
            <Route exact path={BLOG}>
              <Blog />
            </Route>
            <Route path={SERVICES}>
              <Services />
            </Route>
            <Route path={KURUMSAL}>
              <Kurumsal />
            </Route>

            <Route component={NotFound} />
          </Switch>
          <Footer />
        </ScrollToTop>
      </Router>
    </>
  );
}

export default App;

const NotFound = () => <div>404 not found</div>;
