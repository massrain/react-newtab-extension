import React, { useState, useEffect } from "react";
import { useLocation, useHistory } from "react-router-dom";
import {
  SERVICES_ICHASTALIKLARI,
  SERVICES_BEYINVESINIRCERRAHISI,
  SERVICES_UROLOJI,
  SERVICES_ORTOPEDIVETRAVMATOLOJI,
  SERVICES_GOZHASTALIKLARI,
  SERVICES_COCUKHASTALIKLARI,
  SERVICES_KULAKBURUNBOGAZ,
  SERVICES_DIS,
  SERVICES_GENELCERRAHI,
  SERVICES_ANASTEZIVEREANIMASYON,
  SERVICES_KADINDOGUM,
  SERVICES_ACILSERVIS,
  SERVICES_YABANCIHASTALIKLAR,
  SERVICES_RADYOLOJI,
  SERVICES_BIYOKIMYA,
  SERVICES_COCUKCERRAHISI,
  SERVICES_FTR,
  SERVICES_KARDIYOLOJI,
  SERVICES_BESLENMEVEDIYET,
  SERVICES_GOGUSHASTALIKLARI
} from "../../helpers/routes";
import { servicesContent } from "./servicesContent";

const ServicesSingle = () => {
  const [ServiceContent, setServiceContent] = useState([]);
  let location = useLocation();

  useEffect(() => {
    setServiceContent(servicesContent(location.pathname));
  }, [location.pathname]);

  return (
    <>
      <div className="services mt-5">
        <div className="container">
          <div className="row">
            <div className="col-9">
              <div className="row">
                <div className="col text-center">
                  <div className="section_title_container">
                    <div className="section_subtitle">Letoon Hastahanesi</div>
                    <div className="section_title">
                      <h2>{ServiceContent?.title}</h2>
                    </div>
                    <p>{ServiceContent?.text}</p>
                    <hr />
                    <h4>Birimde Görevli Hekimlerimiz </h4>
                    {ServiceContent?.doctors?.map((element, i) => (
                      <h5 key={i}>{element}</h5>
                    ))}
                    <p />
                  </div>
                </div>
              </div>
            </div>
            <div className="col-3">
              <div className="row services_row">
                <SingleService
                  icon={"/assets/images/icon_1.svg"}
                  url={SERVICES_ICHASTALIKLARI}
                  title={"İç hastalıkları"}
                />
                <SingleService
                  icon={"/assets/images/icon_2.svg"}
                  url={SERVICES_BEYINVESINIRCERRAHISI}
                  title={"Beyin ve Sinir Cerrahisi"}
                />
                <SingleService icon={"/assets/images/icon_3.svg"} url={SERVICES_UROLOJI} title={"Üroloji"} />
                <SingleService
                  icon={"/assets/images/icon_4.svg"}
                  url={SERVICES_ORTOPEDIVETRAVMATOLOJI}
                  title={"Ortopedi ve Travmatoloji"}
                />
                <SingleService
                  icon={"/assets/images/icon_5.svg"}
                  url={SERVICES_GOZHASTALIKLARI}
                  title={"Göz Hastalıkları"}
                />
                <SingleService
                  icon={"/assets/images/icon_6.svg"}
                  url={SERVICES_COCUKHASTALIKLARI}
                  title={"Çocuk Hastalıkları"}
                />
                <SingleService
                  icon={"/assets/images/icon_7.svg"}
                  url={SERVICES_KULAKBURUNBOGAZ}
                  title={"Kulak Burun Boğaz"}
                />
                <SingleService icon={"/assets/images/icon_8.svg"} url={SERVICES_DIS} title={"Diş"} />
                <SingleService icon={"/assets/images/icon_1.svg"} url={SERVICES_GENELCERRAHI} title={"Genel Cerrahi"} />
                <SingleService
                  icon={"/assets/images/icon_2.svg"}
                  url={SERVICES_ANASTEZIVEREANIMASYON}
                  title={"Anastezi ve Reanimasyon"}
                />
                <SingleService icon={"/assets/images/icon_3.svg"} url={SERVICES_KADINDOGUM} title={"Kadın Doğum"} />
                <SingleService icon={"/assets/images/icon_4.svg"} url={SERVICES_ACILSERVIS} title={"Acil Servis"} />
                <SingleService
                  icon={"/assets/images/icon_5.svg"}
                  url={SERVICES_YABANCIHASTALIKLAR}
                  title={"Yabancı Hastalıklar"}
                />
                <SingleService icon={"/assets/images/icon_6.svg"} url={SERVICES_RADYOLOJI} title={"Radyoloji"} />
                <SingleService icon={"/assets/images/icon_7.svg"} url={SERVICES_BIYOKIMYA} title={"Biyokimya"} />
                <SingleService
                  icon={"/assets/images/icon_8.svg"}
                  url={SERVICES_COCUKCERRAHISI}
                  title={"Çocuk Cerrahisi"}
                />
                <SingleService icon={"/assets/images/icon_1.svg"} url={SERVICES_FTR} title={"F. T. R"} />
                <SingleService icon={"/assets/images/icon_2.svg"} url={SERVICES_KARDIYOLOJI} title={"Kardiyoloji"} />
                <SingleService
                  icon={"/assets/images/icon_3.svg"}
                  url={SERVICES_BESLENMEVEDIYET}
                  title={"Beslenme ve Diyet"}
                />
                <SingleService
                  icon={"/assets/images/icon_4.svg"}
                  url={SERVICES_GOGUSHASTALIKLARI}
                  title={"Göğüs Hastalıkları"}
                />{" "}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ServicesSingle;

const SingleService = props => {
  let history = useHistory();
  return (
    <div className="col-12 service_col no-margin-bottom">
      <div className="service text-center">
        <div className="service" onClick={() => history.push(props.url)}>
          <div className="service_title p-1">{props.title}</div>
        </div>
      </div>
    </div>
  );
};
