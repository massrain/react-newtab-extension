import {
  SERVICES_ICHASTALIKLARI,
  SERVICES_BEYINVESINIRCERRAHISI,
  SERVICES_UROLOJI,
  SERVICES_ORTOPEDIVETRAVMATOLOJI,
  SERVICES_GOZHASTALIKLARI,
  SERVICES_COCUKHASTALIKLARI,
  SERVICES_KULAKBURUNBOGAZ,
  SERVICES_DIS,
  SERVICES_GENELCERRAHI,
  SERVICES_ANASTEZIVEREANIMASYON,
  SERVICES_KADINDOGUM,
  SERVICES_ACILSERVIS,
  SERVICES_YABANCIHASTALIKLAR,
  SERVICES_RADYOLOJI,
  SERVICES_BIYOKIMYA,
  SERVICES_COCUKCERRAHISI,
  SERVICES_FTR,
  SERVICES_KARDIYOLOJI,
  SERVICES_BESLENMEVEDIYET,
  SERVICES_GOGUSHASTALIKLARI
} from "../../helpers/routes";

import textContent from "./textContent";

export const servicesContent = location => {
  let data;
  switch (location) {
    case SERVICES_ICHASTALIKLARI:
      data = textContent.SERVICES_ICHASTALIKLARI;
      break;
    case SERVICES_BEYINVESINIRCERRAHISI:
      data = textContent.SERVICES_BEYINVESINIRCERRAHISI;
      break;
    case SERVICES_UROLOJI:
      data = textContent.SERVICES_UROLOJI;
      break;
    case SERVICES_ORTOPEDIVETRAVMATOLOJI:
      data = textContent.SERVICES_ORTOPEDIVETRAVMATOLOJI;
      break;
    case SERVICES_GOZHASTALIKLARI:
      data = textContent.SERVICES_GOZHASTALIKLARI;
      break;
    case SERVICES_COCUKHASTALIKLARI:
      data = textContent.SERVICES_COCUKHASTALIKLARI;
      break;
    case SERVICES_KULAKBURUNBOGAZ:
      data = textContent.SERVICES_KULAKBURUNBOGAZ;
      break;
    case SERVICES_DIS:
      data = textContent.SERVICES_DIS;
      break;
    case SERVICES_GENELCERRAHI:
      data = textContent.SERVICES_GENELCERRAHI;
      break;
    case SERVICES_ANASTEZIVEREANIMASYON:
      data = textContent.SERVICES_ANASTEZIVEREANIMASYON;
      break;
    case SERVICES_KADINDOGUM:
      data = textContent.SERVICES_KADINDOGUM;
      break;
    case SERVICES_ACILSERVIS:
      data = textContent.SERVICES_ACILSERVIS;
      break;
    case SERVICES_YABANCIHASTALIKLAR:
      data = textContent.SERVICES_YABANCIHASTALIKLAR;
      break;
    case SERVICES_RADYOLOJI:
      data = textContent.SERVICES_RADYOLOJI;
      break;
    case SERVICES_BIYOKIMYA:
      data = textContent.SERVICES_BIYOKIMYA;
      break;
    case SERVICES_COCUKCERRAHISI:
      data = textContent.SERVICES_COCUKCERRAHISI;
      break;
    case SERVICES_FTR:
      data = textContent.SERVICES_FTR;
      break;
    case SERVICES_KARDIYOLOJI:
      data = textContent.SERVICES_KARDIYOLOJI;
      break;
    case SERVICES_BESLENMEVEDIYET:
      data = textContent.SERVICES_BESLENMEVEDIYET;
      break;
    case SERVICES_GOGUSHASTALIKLARI:
      data = textContent.SERVICES_GOGUSHASTALIKLARI;
      break;
    default:
      break;
  }
  return data;
};
