import React from "react";
import Sidebar from "../pages/Sidebar";

const ZiyaretciRehberi = () => {
  return (
    <>
      <div className="services mt-5">
        <div className="container">
          <div className="row">
            <div className="col-9">
              <div className="row">
                <div className="col text-center">
                  <div className="section_title_container text-left">
                    <div className="section_title">
                      <h2>Ziyaretçi Rehberi</h2>
                    </div>
                    <p className="font-weight-bold">
                      Hastanemizde ziyaret saatlerimiz hafta içi 12:00-14:00,17:00-19:00 hafta sonu 12:00-19:00 saatleri arasındadır.
                    </p>
                    <p>
                      Hastane düzenin sağlanması ve yatan hastalarımızın refahı açısından bu saatler dışında ziyaretçi kabul edilmemektedir.
                    </p>
                    <p className="font-weight-bold">Bu konuda anlayışınız için teşekkür ederiz.</p>
                    <hr />
                    <p className="font-weight-bold">
                      Hastanemize, yakınlarını ziyarete gelen kişilerin aşağıda belirtilen kurallara riayet etmeleri rica olunur.
                    </p>
                    <p>- Ziyarete 0-16 yaş arası çocukları getirmeyiniz.</p>
                    <p>- Ziyaretçiler tarafından hastalara dergi ve kitap hediye getirilebilir</p>
                    <p>- Lütfen canlı çiçek, yiyecek ve içecek getirmeyiniz</p>
                    <p>- Hasta odalarında, yangın merdivenlerinde kesinlikle sigara içmeyiniz</p>
                    <p>- Yataklara oturmayınız</p>
                    <p>- Ziyareti kısa süreli tutunuz</p>
                    <p>- Yerlere çöp atmayınız</p>
                    <p>- Görevlilerin talimatlarına uyunuz</p>
                    <p>
                      - Olumlu ve olumsuz yönlermizi şikayet ve memnuniyet bildirim formu’nu doldurarak şikayet ve öneri kutumuza atınız.
                    </p>
                    <p>- Bir gün aynı hastanede hasta olarak yatacağınızı düşünerek hareket ediniz.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-3">
              <div className="row services_row">
                <Sidebar />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ZiyaretciRehberi;
