import React from "react";
import { useHistory } from "react-router-dom";
import {
  KURUMSAL_HASTAHANEMIZ,
  KURUMSAL_KALITEPOLITIKASI,
  KURUMSAL_MISYON,
  KURUMSAL_VIZYON,
  KURUMSAL_GALERI,
  KURUMSAL_HALKLAILISKILER,
  KURUMSAL_REFAKATCIREHBERI,
  KURUMSAL_ZIYARETCIREHBERI,
  KURUMSAL_HASTASORUMLULUKLARI,
  KURUMSAL_HASTAHAKLARI,
  KURUMSAL_ANLASMALIKURUMLAR
} from "../../../helpers/routes";
const Sidebar = () => {
  let history = useHistory();
  return (
    <>
      <div className="col-12 service_col no-margin-bottom">
        <div className="service text-center">
          <div className="service" onClick={() => history.push(KURUMSAL_HASTAHANEMIZ)}>
            <div className="service_title p-1">Hastahanemiz</div>
          </div>
        </div>
      </div>
      <div className="col-12 service_col no-margin-bottom">
        <div className="service text-center">
          <div className="service" onClick={() => history.push(KURUMSAL_KALITEPOLITIKASI)}>
            <div className="service_title p-1">Kalite Politikamız</div>
          </div>
        </div>
      </div>
      <div className="col-12 service_col no-margin-bottom">
        <div className="service text-center">
          <div className="service" onClick={() => history.push(KURUMSAL_MISYON)}>
            <div className="service_title p-1">Misyonumuz</div>
          </div>
        </div>
      </div>
      <div className="col-12 service_col no-margin-bottom">
        <div className="service text-center">
          <div className="service" onClick={() => history.push(KURUMSAL_VIZYON)}>
            <div className="service_title p-1">Vizyonumuz</div>
          </div>
        </div>
      </div>
      <div className="col-12 service_col no-margin-bottom">
        <div className="service text-center">
          <div className="service" onClick={() => history.push(KURUMSAL_GALERI)}>
            <div className="service_title p-1">Galeri</div>
          </div>
        </div>
      </div>
      <div className="col-12">
        <hr className="border-secondary" />
      </div>
      <div className="col-12 service_col no-margin-bottom">
        <div className="service text-center">
          <div className="service" onClick={() => history.push(KURUMSAL_HASTAHAKLARI)}>
            <div className="service_title p-1">Hasta Hakları</div>
          </div>
        </div>
      </div>
      <div className="col-12 service_col no-margin-bottom">
        <div className="service text-center">
          <div className="service" onClick={() => history.push(KURUMSAL_HASTASORUMLULUKLARI)}>
            <div className="service_title p-1">Hasta Sorumlulukları</div>
          </div>
        </div>
      </div>
      <div className="col-12 service_col no-margin-bottom">
        <div className="service text-center">
          <div className="service" onClick={() => history.push(KURUMSAL_ZIYARETCIREHBERI)}>
            <div className="service_title p-1">Ziyaretçi Rehberi</div>
          </div>
        </div>
      </div>
      <div className="col-12 service_col no-margin-bottom">
        <div className="service text-center">
          <div className="service" onClick={() => history.push(KURUMSAL_REFAKATCIREHBERI)}>
            <div className="service_title p-1">Refakatçi Rehberi</div>
          </div>
        </div>
      </div>
      <div className="col-12 service_col no-margin-bottom">
        <div className="service text-center">
          <div className="service" onClick={() => history.push(KURUMSAL_HALKLAILISKILER)}>
            <div className="service_title p-1">Halkla İlişkiler</div>
          </div>
        </div>
      </div>
      <div className="col-12 service_col no-margin-bottom">
        <div className="service text-center">
          <div className="service" onClick={() => history.push(KURUMSAL_ANLASMALIKURUMLAR)}>
            <div className="service_title p-1">Anlaşmalı Kurumlar</div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
