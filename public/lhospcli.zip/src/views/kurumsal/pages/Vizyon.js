import React from "react";
import Sidebar from "./Sidebar";

const Vizyon = () => {
  return (
    <>
      <div className="services mt-5">
        <div className="container">
          <div className="row">
            <div className="col-9">
              <div className="row">
                <div className="col text-center">
                  <div className="section_title_container text-left">
                    <div className="section_title">
                      <h2>Vizyonumuz</h2>
                    </div>
                    <p>
                      Biz, kendimizi kişi ve kurum olarak bilimsel, vicdani, etik ve ilkelerinden asla ödün vermeden insan onuruna saygılı,
                      açık, dürüst, güvenilir ve en yüksek kalitede sağlık hizmetleri sunmaya adamış bulunuyoruz,
                    </p>
                    <p>Kendimizi adadığımız işin insanlık için anlam, önem ve kutsallığını asla unutmuyoruz,</p>
                    <p>
                      "En yüce değer bilgi; en üstün hizmet insana hizmettir" inanç ve anlayışı bizim için bir yaşam felsefesi ve tarzıdır.
                      Bu inanç ve anlayışla bütün insanlığı kucaklayan Özel Letoon Hospital, Fethiyemiz ve çevresi için en önde gelen bir
                      referans merkezi olacaktır.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-3">
              <div className="row services_row">
                <Sidebar />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Vizyon;
