{
    "0":{
      "img": "/assets/images/doctors/kadiraydogmus.jpg",
      "name": "Dr. Kadir AYDOĞMUŞ",
      "birim": "Yabancı Hasta Birimi",
      "unvan": "Başhekim",
      "ozgecmis" : "test"
    },
    "1":{
      "img": "/assets/images/doctors/mustafakorucu.jpg",
      "name": "Op. Dr. Mustafa Korucu",
      "birim": "Beyin ve Sinir Cerrahi",
      "unvan": "",
      "ozgecmis" : "test"
    },
    "2":{
      "img": "/assets/images/doctors/osmannuribuyuker.jpg",
      "name": "Op. Dr. Osman Nuri Büyüker",
      "birim": "Çocuk Cerrahisi",
      "unvan": "",
      "ozgecmis" : "test"
    },
    "3":{
      "img": "/assets/images/doctors/huseyinhelvaci.jpg",
      "name": "Uz. Dr. Hüseyin Helvacı",
      "birim": "Çocuk Doktoru",
      "unvan": "",
      "ozgecmis" : "test"
    },
    "4":{
      "img": "/assets/images/doctors/yaseminonursalhelvaci.jpg",
      "name": "Uz. Dr. Yasemin Onursal Helvacı",
      "birim": "Çocuk Doktoru",
      "unvan": "",
      "ozgecmis" : "test"
    },
    "5":{
      "img": "/assets/images/doctors/behzatguler.jpg",
      "name": "Uz. Dr. Behzat Güler",
      "birim": "Dahiliye",
      "unvan": "",
      "ozgecmis" : "test"
    },
    "6": {
      "img": "/assets/images/doctors/servetemeksiz.jpg",
      "name": "Op. Dr. Servet Emeksiz",
      "birim": "Genel Cerrahi",
      "unvan": "",
      "ozgecmis" : "test"
    },
    "8":{
      "img": "/assets/images/doctors/ahmetguldas.jpg",
      "name": "Op. Dr. Ahmet Güldaş",
      "birim": "Kadın Hastalıkları ve Doğum",
      "unvan": "",
      "ozgecmis" : "test"
    },
    "9":{
      "img": "/assets/images/doctors/nacigemici.jpg",
      "name": "Uz. Dr. Naci Gemici",
      "birim": "Nöroloji",
      "unvan": "",
      "ozgecmis" : "test"
    },
    "10":{
      "img": "/assets/images/doctors/alperarikan.jpg",
      "name": "Op. Dr. Alper Arıkan",
      "birim": "Ortopedi",
      "unvan": "",
      "ozgecmis" : "test"
    },
    "11":{
      "img": "/assets/images/doctors/mertkeskinbora.jpeg",
      "name": "Op. Dr. Mert Keskin Bora",
      "birim": "Ortopedi",
      "unvan": "",
      "ozgecmis" : "test"
    },
    "12":{
      "img": "/assets/images/doctors/mehmetmunduz.jpg",
      "name": "Uz. Dr. Mehmet Munduz",
      "birim": "Radyoloji",
      "unvan": "",
      "ozgecmis" : "test"
    },
    "13": {
      "img": "/assets/images/doctors/nailkocer.jpg",
      "name": "Uz. Dr. Nail Koçer",
      "birim": "Radyoloji",
      "unvan": "",
      "ozgecmis" : "test"
    },
    "14": {
      "img": "/assets/images/doctors/jasurdjamilov.jpg",
      "name": "Op. Dr. Jasur Djamilov",
      "birim": "Üroloji",
      "unvan": "",
      "ozgecmis" : "test"
    }
}