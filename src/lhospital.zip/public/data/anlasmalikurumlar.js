{
    "0": {
      "img": "/assets/images/new/kurumlar/sgklogo.gif",
      "name": "Sosyal Güvenlik Kurumu"
    },
    "1": {
      "img": "/assets/images/new/kurumlar/tbmm.jpg",
      "name": "Türkiye Büyük Millet Meclisi"
    },
    "2": {
      "img": "/assets/images/new/kurumlar/acibadem.jpg",
      "name": "Acıbadem Sigorta"
    },
    "3": {
      "img": "/assets/images/new/kurumlar/allianz.jpg",
      "name": "Allianz Sigorta"
    },
    "4": {
      "img": "/assets/images/new/kurumlar/interpartner.jpg",
      "name": "Interpartner Assistance"
    },
    "5": {
      "img": "/assets/images/new/kurumlar/paphregenelyasam.png",
      "name": "Maphre Genel Yaşam"
    },
    "6": {
      "img": "/assets/images/new/kurumlar/yapikredi.jpg",
      "name": "Yapı Kredi Sigorta"
    },
    "7": {
      "img": "/assets/images/new/kurumlar/basakgroupama.jpg",
      "name": "Başak Groupama"
    },
    "8": {
      "img": "/assets/images/new/kurumlar/sekerbank.jpg",
      "name": "Şekerbank"
    },
    "9": {
      "img": "/assets/images/new/kurumlar/aksigorta.jpg",
      "name": "Ak Sigorta"
    },
    "10": {
      "img": "/assets/images/new/kurumlar/ergo.jpg",
      "name": "Ergo Sigorta"
    },
    "11": {
      "img": "/assets/images/new/kurumlar/zurich.jpg",
      "name": "Zurich Sigorta"
    },
    "12": {
      "img": "/assets/images/new/kurumlar/axa.jpg",
      "name": "Axa Hayat Emeklilik"
    },
    "13": {
      "img": "/assets/images/new/kurumlar/demir.jpg",
      "name": "Demir Hayat"
    },
    "14": {
      "img": "/assets/images/new/kurumlar/turkiyeassist.jpg",
      "name": "Türkiye Assist"
    },
    "15": {
      "img": "/assets/images/new/kurumlar/Anadolu-sigorta.jpg",
      "name": "Anadolu Sigorta"
    }
  }
  