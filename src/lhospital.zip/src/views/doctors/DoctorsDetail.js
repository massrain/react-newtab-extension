import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";

const DoctorsDetail = () => {
  const [Doctors, setDoctors] = useState([]);
  const [SingleDoc, setSingleDoc] = useState(null);
  let location = useLocation();

  function json2array(json) {
    var result = [];
    var keys = Object.keys(json);
    keys.forEach(key => {
      result.push(json[key]);
    });
    return result;
  }

  useEffect(() => {
    fetch("/data/doctors.js")
      .then(response => {
        return response.json();
      })
      .then(data => {
        setDoctors(json2array(data));
      });
  }, []);

  useEffect(() => {
    let stringURL = location.pathname;
    let doctorId = stringURL.substring(20);
    setSingleDoc(Doctors[doctorId]);
  }, [Doctors, location.pathname]);

  console.log(SingleDoc);
  return (
    <>
      {SingleDoc ? (
        <div className="services mt-5">
          <div className="container">
            <div className="row no-gutters justify-content-center text-center mt-3">
              <div className="col-8">
                <div className="row no-gutters">
                  <div className="col justify-content-center text-center">
                    <div className="section_title_container">
                      <div className="section_title">
                        <img src={SingleDoc.img} alt="" className="img-fluid" />
                      </div>
                      <h3>{SingleDoc.name}</h3>
                      <h5>{SingleDoc.birim}</h5>
                      <p>{SingleDoc.unvan}</p>
                      <p>{SingleDoc.ozgecmis}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <Loading />
      )}
    </>
  );
};

export default DoctorsDetail;

const Loading = () => (
  <>
    <div className="services mt-5">
      <div className="container">
        <div className="row no-gutters">
          <div className="col-9">
            <div className="row no-gutters">
              <div className="col text-center">
                <div className="section_title_container text-left">
                  <div className="section_title">
                    <h2>Geçersiz doktor bilgisi.</h2>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </>
);
