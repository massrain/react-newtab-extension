import React from "react";
import Sidebar from "./Sidebar";

const Misyon = () => {
  return (
    <>
      <div className="services mt-5">
        <div className="container">
          <div className="row">
            <div className="col-9">
              <div className="row">
                <div className="col text-center">
                  <div className="section_title_container text-left">
                    <div className="section_title">
                      <h2>Misyonumuz</h2>
                    </div>
                    <p>Bilimsel ve etik ilkelerden ödün vermeden açık, dürüst, güvenilir bir tanı ve tedavi hizmeti sunmak, </p>
                    <p>
                      Sürekli eğitim, ölçme, iyileştirme yöntemleri kullanarak devamlı gelişmeyi, yenilenmeyi sağlayan bir yöntem ve işletim
                      sistemi örneği vermek,
                    </p>
                    <p>
                      Hastalarımızın ve çalışanlarımızın memnuniyetine odaklı yüksek kalitede sağlık hizmetlerini gönülden ve en uygun
                      fiyatlarla sunmak.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-3">
              <div className="row services_row">
                <Sidebar />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Misyon;
