import React from "react";
import Sidebar from "../pages/Sidebar";

const HalklaIliskiler = () => {
  return (
    <>
      <div className="services mt-5">
        <div className="container">
          <div className="row">
            <div className="col-9">
              <div className="row">
                <div className="col text-center">
                  <div className="section_title_container text-left">
                    <div className="section_title">
                      <h2>Halkla İlişkiler</h2>
                    </div>
                    <p>
                      Kurumumuz amaçlarına ulaşmasında çevreyle bütünleşmesi temel bir zorunluluk haline gelmiştir. Halkla ilişkiler
                      uygulamalarının dikkatle ele alınması gerekliliğini ortaya koymaktadır. “Halkla ilişkiler, bir örgüt ile hedef kitle
                      arasında karşılıklı iletişimi, anlayışı oluşturmaya ve sürdürmeye yardımcı olan ayrıcalıklı bir yönetim görevidir”
                    </p>
                    <p>Hedef kitle ile hizmet veya ürün sunan işletme arasında olumlu yönde çift yönlü iletişim sağlama sürecidir. </p>
                    <p>
                      Söz konusu kurum sağlık hizmeti veren hastaneler olduğunda hedef kitleyle olumlu yönde iletişim kurmak ve anlayış
                      oluşturmak daha da önemlidir.
                    </p>
                    <p>
                      Hastanemiz örgüt yapısı itibariyle diğer kurumlardan büyük farklılıklar taşımakta, hedef kitlesi sağlık konusu göz
                      önünde bulundurulduğunda çok daha fazla ilgi bekleyen gruplardan oluşmaktadır.
                    </p>
                    <p>
                      Bu çerçevede de söz konusu kitlelere ulaşmak ve onlarda istenilen değişiklikleri yaratmak diğer kurumlara oranla çok
                      daha fazla çaba gerektirmektedir. Hastanemizde ve toplumdaki bireylere ulaşabilmek, onlarla bütünleşebilmek bunun
                      sonucunda da olumlu bir imaj yaratabilmek planlı iletişim çalışmaları ile mümkün olabilmektedir.
                    </p>
                    <p>Bu bağlamda hastanemizde halkla ilişkiler birimi önemli bir yere sahiptir.</p>
                    <p>
                      Hastanemizde yapılan halkla ilişkiler uygulamaları, bir hastalık hakkında kamuoyunu bilgilendirmekten başlayan,
                      onların hastalıklarının farkında olmasını sağlamaya, hastalıklarıyla mücadele etme yöntemlerinin ve korunma yollarının
                      anlatılmasına, hasta memnuniyetinin sağlanmasından hasta haklarına ilişkin bilgilendirmenin yapılmasına, tüm
                      paydaşlarla ilişkilerin yönetilmesinden hedef kitle üzerinde olumlu bir kurumsal imaj yerleştirilmesine kadar çok
                      geniş bir yelpazede değerlendirilmektedir.
                    </p>
                    <p>
                      Olumlu kurum imajı üzerinde önemli bir etkiye sahip olan kalite unsuru, sağlık sektöründe tüm paydaşların
                      beklentilerinin dikkate alınmasını gerekli kılmaktadır.
                    </p>
                    <p>
                      Tedarikçilerin, doktorların, hastaların ve diğer çalışanların farklı beklentileri arasında denge kurulmalı ve çift
                      yönlü bir iletişim sistemi tasarlanmalıdır.
                    </p>
                    <p>
                      Söz konusu çalışmalarda, toplumun farklı kesimlerine hitap edebilecek yalınlıkta mesajların hazırlanarak geniş
                      kitlelere ulaşılması, halkla ilişkiler meslek ilkelerinin yanı sıra deontolojiye uygun olarak hareket edilmesi
                      gerekmektedir.
                    </p>
                    <p>
                      Toplumla etkileşime geçilen her noktada verilecek her mesajın bilimsel temellere dayandırılması ve içinde yaşanılan
                      toplumun değerlerine özen gösterilmesi kısa dönemde etkin iletişim sağlanarak kitlelere ulaşılmasında ve kitlelerin
                      hastane hizmetlerinden haberdar edilmesinde uzun dönemde ise olumlu bir kurum imajı yaratılmasında belirleyici
                      olmaktadır.
                    </p>
                    <p>
                      Sonuç olarak hastanelerde halkla ilişkiler birimlerinin yapı, işlev ve uygulamalarına yönelik çalışmalar bir bütün
                      olarak değerlendirilmelidir. Halkla ilişkilerin önemine ilişkin tüm unsurlar göz önüne alındığında gerek kamuda
                      gerekse özel sektörde hastane yönetimlerinden beklenen halkla ilişkiler birimlerini çağdaş yönetim anlayışına uygun
                      olarak oluşturmaları ve söz konusu birimin işlevselliğini sağlamalarıdır. Bunun sonucunda hem sağlık hizmeti alıcıları
                      daha etkin bir biçimde hizmet alacak hem de hastanelerin kurumsal başarı oranları yükselecektir.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-3">
              <div className="row services_row">
                <Sidebar />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default HalklaIliskiler;
