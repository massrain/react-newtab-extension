/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { useTranslation } from "react-i18next";
import {
  HOME,
  CONTACT,
  DOCTORS,
  SERVICES,
  KURUMSAL_HASTAHANEMIZ,
  KURUMSAL_KALITEPOLITIKASI,
  KURUMSAL_MISYON,
  KURUMSAL_VIZYON,
  KURUMSAL_GALERI,
  KURUMSAL_HASTAHAKLARI,
  KURUMSAL_HASTASORUMLULUKLARI,
  KURUMSAL_ZIYARETCIREHBERI,
  KURUMSAL_REFAKATCIREHBERI,
  KURUMSAL_HALKLAILISKILER,
  KURUMSAL_ANLASMALIKURUMLAR
} from "../../helpers/routes";

const Navbar = () => {
  const [Lang, setLang] = useState("EN");
  const { t, i18n } = useTranslation();

  const changeLanguage = () => {
    if (i18n.language.toUpperCase())
      if (i18n.language.toUpperCase() === "EN") {
        i18n.changeLanguage("tr");
        setLang("EN");
      } else if (i18n.language.toUpperCase() === "TR") {
        i18n.changeLanguage("en");
        setLang("TR");
      }
  };

  return (
    <>
      <div className="super_container">
        {/* Header */}
        <header className="header trans_400">
          <div className="header_content d-flex flex-row align-items-center jusity-content-start trans_400">
            {/* Logo */}
            <div className="logo">
              <Link to={HOME}>
                <img src="/assets/images/letoonlogo.png" alt="" className="img-fluid" />
              </Link>
            </div>
            {/* Main Navigation */}
            <nav className="main_nav">
              <ul className="d-flex flex-row align-items-center justify-content-start">
                <li>
                  <NavLink exact to={HOME} activeClassName="custom-selected-link">
                    {t("navbar.anasayfa")}
                  </NavLink>
                </li>
                <li>
                  <div className="dropdown">
                    <a className="btn btn-link dropdown-toggle" href="#" data-toggle="dropdown">
                      {t("navbar.kurumsal")}
                    </a>
                    <div className="dropdown-menu">
                      <NavLink exact to={KURUMSAL_HASTAHANEMIZ} className="dropdown-item" activeClassName="custom-selected-link">
                        {t("navbar.kurumsal_hastanemiz")}
                      </NavLink>
                      <NavLink exact to={KURUMSAL_KALITEPOLITIKASI} className="dropdown-item" activeClassName="custom-selected-link">
                        {t("navbar.kurumsal_kalitepolitikamiz")}
                      </NavLink>
                      <NavLink exact to={KURUMSAL_MISYON} className="dropdown-item" activeClassName="custom-selected-link">
                        {t("navbar.kurumsal_misyonumuz")}
                      </NavLink>
                      <NavLink exact to={KURUMSAL_VIZYON} className="dropdown-item" activeClassName="custom-selected-link">
                        {t("navbar.kurumsal_vizyonumuz")}
                      </NavLink>
                      <NavLink exact to={KURUMSAL_GALERI} className="dropdown-item" activeClassName="custom-selected-link">
                        {t("navbar.kurumsal_galeri")}
                      </NavLink>
                      <div className="dropdown-divider"></div>
                      <NavLink exact to={KURUMSAL_HASTAHAKLARI} className="dropdown-item" activeClassName="custom-selected-link">
                        {t("navbar.kurumsal_hastahaklari")}
                      </NavLink>
                      <NavLink exact to={KURUMSAL_HASTASORUMLULUKLARI} className="dropdown-item" activeClassName="custom-selected-link">
                        {t("navbar.kurumsal_hastasorumluluklari")}
                      </NavLink>
                      <NavLink exact to={KURUMSAL_ZIYARETCIREHBERI} className="dropdown-item" activeClassName="custom-selected-link">
                        {t("navbar.kurumsal_ziyaretcirehberi")}
                      </NavLink>
                      <NavLink exact to={KURUMSAL_REFAKATCIREHBERI} className="dropdown-item" activeClassName="custom-selected-link">
                        {t("navbar.kurumsal_refakatcirehberi")}
                      </NavLink>
                      <NavLink exact to={KURUMSAL_HALKLAILISKILER} className="dropdown-item" activeClassName="custom-selected-link">
                        {t("navbar.kurumsal_halklailiskiler")}
                      </NavLink>
                      <NavLink exact to={KURUMSAL_ANLASMALIKURUMLAR} className="dropdown-item" activeClassName="custom-selected-link">
                        {t("navbar.kurumsal_anlasmalikurumlar")}
                      </NavLink>
                    </div>
                  </div>
                </li>
                <li>
                  <NavLink exact to={SERVICES} activeClassName="custom-selected-link">
                    {t("navbar.birimlerimiz")}
                  </NavLink>
                </li>
                <li>
                  <NavLink exact to={DOCTORS} activeClassName="custom-selected-link">
                    {t("navbar.hekimlerimiz")}
                  </NavLink>
                </li>
                <li>
                  <NavLink exact to={CONTACT} activeClassName="custom-selected-link">
                    {t("navbar.iletisim")}
                  </NavLink>
                </li>
                <li>
                  <NavLink exact to={KURUMSAL_ANLASMALIKURUMLAR} activeClassName="custom-selected-link">
                    {t("navbar.kurumsal_anlasmalikurumlar")}
                  </NavLink>
                </li>
              </ul>
            </nav>
            <div className="header_extra d-flex flex-row align-items-center justify-content-end ml-auto">
              {/* Work Hourse */}
              {/* Appointment Button */}
              <div className="button button_1 header_button">
                <a href="https://gothru.co/PqJckbdNz?index=scene_0&hlookat=263&vlookat=5&fov=100">{t("navbar.sanaltur")}</a>
              </div>
              {/* Header Social */}
              <div className="social header_social">
                <ul className="d-flex flex-row align-items-center justify-content-start">
                  <li>
                    <a href="https://www.youtube.com/c/LetoonhospitalTr">
                      <i className="fa fa-youtube" />
                    </a>
                  </li>
                  <li>
                    <a href="https://www.facebook.com/ozelletoonhospital">
                      <i className="fa fa-facebook" />
                    </a>
                  </li>
                  <li>
                    <a href="https://twitter.com/letoonhospital">
                      <i className="fa fa-twitter" />
                    </a>
                  </li>
                  <li>
                    <a href="https://www.instagram.com/letoonhospital/">
                      <i className="fa fa-instagram" />
                    </a>
                  </li>
                  <li>
                    <button className="btn btn-sm btn-outline-info rounded-circle" onClick={changeLanguage}>
                      <small>{Lang}</small>
                    </button>
                  </li>
                </ul>
              </div>
              {/* Hamburger */}
              <div className="hamburger">
                <i className="fa fa-bars" />
              </div>
            </div>
          </div>
        </header>
        {/* Menu */}
        <div className="menu_overlay trans_400" />
        <div className="menu trans_400">
          <div className="menu_close_container">
            <div className="menu_close">
              <div />
              <div />
            </div>
          </div>
          <nav className="menu_nav">
            <ul>
              <li>
                <Link to={HOME}>{t("navbar.anasayfa")}</Link>
              </li>
              <li>
                <Link to={KURUMSAL_HASTAHANEMIZ}>{t("navbar.kurumsal")}</Link>
              </li>
              <li>
                <Link to={SERVICES}>{t("navbar.birimlerimiz")}</Link>
              </li>
              <li>
                <Link to={DOCTORS}>{t("navbar.hekimlerimiz")}</Link>
              </li>
              <li>
                <Link to={CONTACT}>{t("navbar.iletisim")}</Link>
              </li>
            </ul>
          </nav>
          <div className="social menu_social">
            <ul className="d-flex flex-row align-items-center justify-content-start">
              <li>
                <a href="https://www.youtube.com/c/LetoonhospitalTr">
                  <i className="fa fa-youtube" />
                </a>
              </li>
              <li>
                <a href="https://www.facebook.com/ozelletoonhospital">
                  <i className="fa fa-facebook" />
                </a>
              </li>
              <li>
                <a href="https://twitter.com/letoonhospital">
                  <i className="fa fa-twitter" />
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
};

export default Navbar;
