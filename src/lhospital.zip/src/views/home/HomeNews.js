import React, { useState, useEffect } from "react";
import BlogSingle from "../blog/BlogSingle";

const HomeNews = () => {
  const [Duyurular, setDuyurular] = useState([]);

  function json2array(json) {
    var result = [];
    var keys = Object.keys(json);
    keys.forEach(function(key) {
      result.push(json[key]);
    });
    return result;
  }

  useEffect(() => {
    fetch("/data/duyurular.js")
      .then(response => {
        return response.json();
      })
      .then(data => {
        setDuyurular(json2array(data));
      });
  }, []);

  const blogStyle = { paddingTop: "30px", paddingBottom: "25px" };
  return (
    <>
      <div className="blog" style={blogStyle}>
        <div className="container">
          <div className="row">
            <div className="col text-center justify-content-center">
              {Duyurular.map((element, i, { length }) => {
                if (length - 1 === i || length - 2 === i) {
                  return <BlogSingle data={element} key={i} />;
                } else {
                  return null;
                }
              })}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default HomeNews;
