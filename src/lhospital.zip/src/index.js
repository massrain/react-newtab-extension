import React, { Suspense } from "react";
import ReactDOM from "react-dom";
import "./index.css";
import App from "./App";
import "./translations/i18n";

ReactDOM.render(
  <Suspense
    fallback={
      <div className="svg-load">
        <img src="/assets/images/new/loading.svg" className="img-fluid" alt="" />
      </div>
    }
  >
    <App />
  </Suspense>,
  document.getElementById("root")
);
